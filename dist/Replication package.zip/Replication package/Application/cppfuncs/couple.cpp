// Functions for solving the model for couples.
#ifndef MAIN
#define COUPLE
#include "myheader.cpp"
#endif

namespace couple {

    struct SolverData {
        int t;
        int ilw;
        int ilm;
        int iL;
        int iP;
        double Kw;
        double Km;
        double M;
        double* EVw_next;
        double* EVm_next;
        sol_struct* sol;
        par_struct* par;
    };


    double tax_couple(double income, par_struct* par) {

        // Define brackets and their rates in one place
        // Each row: {bracket top, rate applied up to that top}
        int    num_brackets     = 5;
        double bracket_tops[5]  = {43850.0, 105950.0, 161450.0, 288350.0, 1e308};
        double bracket_rates[5] = {15.0, 28.0, 31.0, 36.0, 39.6};

        for (int i = 0; i < num_brackets; i++) {
            bracket_tops[i] = bracket_tops[i] / par->money_metric;
            bracket_rates[i] = bracket_rates[i] / 100.0;
        }

        double tax        = 0.0;
        double prev_top   = 0.0;

        for (int i = 0; i < num_brackets; i++) {
            double bracket_income = 0.0;
            if (income <= bracket_tops[i]) {
                bracket_income = income - prev_top;
                tax += bracket_income * bracket_rates[i];
                return tax;
            }
            bracket_income = bracket_tops[i] - prev_top;
            tax += bracket_income * bracket_rates[i];
            prev_top = bracket_tops[i];
        }

        return tax;

    }


    double after_tax_income_couple(int type_w, int type_m, double labor_w, double labor_m, double Kw, double Km, double A, par_struct* par) {
        // If no labor income, return asset income plus small epsilon to avoid zero
        if ((labor_w == 0.0) && (labor_m == 0.0)) {
            return 1.0e-4 + (par->R - 1.0) * A;
        }

        double wage_w = utils::wage_income(type_w, labor_w, Kw, woman, par);
        double wage_m = utils::wage_income(type_m, labor_m, Km, man, par);
        double gross_wage_income = wage_w + wage_m;

        // income floor
        if (gross_wage_income < 0.0001) {
            gross_wage_income = 0.0001;
        }
        double tax = tax_couple(gross_wage_income, par);
        return gross_wage_income - tax + (par->R - 1.0) * A;
    }

    double resources_couple(int type_w, int type_m, double labor_w, double labor_m, double Kw, double Km, double A, par_struct* par) {
        double after_tax_income = after_tax_income_couple(type_w, type_m, labor_w, labor_m, Kw, Km, A, par);
        return A + after_tax_income; // note that interest rates of A are included in after_tax_income
    }

    double value_of_choice_couple_to_couple(double* Cw_priv, double* Cm_priv, double* hw, double* hm,
        double* C_inter, double* Q, int ilw, int ilm, double C_tot, double Kw, double Km, double M_resources,
        int t, int iL, int iP, double* Vw, double* Vm, double* EVw_next, double* EVm_next,
        par_struct* par, sol_struct* sol)
    {
        double love = par->grid_love[iL];
        double power = par->grid_power[iP];

        precompute::intraperiod_allocation_couple(Cw_priv, Cm_priv, hw, hm, C_inter, Q,
            ilw, ilm, iP, power, C_tot, par, sol, par->precompute_intratemporal, true /*use_power_index*/);

        Vw[0] = utils::util(*Cw_priv, *hw + par->grid_l[ilw], *Q, woman, par, love);
        Vm[0] = utils::util(*Cm_priv, *hm + par->grid_l[ilm], *Q, man, par, love);

        if (t < (par->T - 1)) {
            double A_next = M_resources - C_tot;
            double Kw_next = utils::human_capital_transition(Kw, par->grid_l[ilw], par);
            double Km_next = utils::human_capital_transition(Km, par->grid_l[ilm], par);
            
            double EVw_plus = 0;
            double EVm_plus = 0;
            tools::interp_3d_2out(par->grid_Kw, par->grid_Km, par->grid_A, par->num_K, par->num_K, par->num_A, EVw_next, EVm_next, Kw_next, Km_next, A_next, &EVw_plus, &EVm_plus);
            
            Vw[0] += par->beta * EVw_plus;
            Vm[0] += par->beta * EVm_plus;
        }

        return power * Vw[0] + (1.0 - power) * Vm[0];
    }

    //////////////////
    // VFI solution
    double objfunc_couple_to_couple(unsigned /*n*/, const double* x, double* /*grad*/, void* solver_data_in) {
        auto* d = static_cast<SolverData*>(solver_data_in);
        double C_tot = x[0];

        double Cw_priv, Cm_priv, hw, hm, C_inter, Q, Vw, Vm;
        return -value_of_choice_couple_to_couple(&Cw_priv, &Cm_priv, &hw, &hm, &C_inter, &Q,
            d->ilw, d->ilm, C_tot, d->Kw, d->Km,d->M, d->t, d->iL, d->iP,
            &Vw, &Vm, d->EVw_next, d->EVm_next, d->par, d->sol);
    }

    void solve_couple_to_couple_step(double* Cw_priv, double* Cm_priv, double* hw, double* hm,
        double* C_inter, double* Q, double* Vw, double* Vm, double Kw, double Km, double M_resources,
        int t, int ilw, int ilm, int iL, int iP, double* EVw_next, double* EVm_next,
        double starting_val, sol_struct* sol, par_struct* par)
    {
        double C_tot = M_resources;

        if (t < (par->T - 1)) {
            const int dim = 1;
            double lb[dim], ub[dim];
            double x[dim] = { starting_val };

            auto opt = nlopt_create(NLOPT_LN_BOBYQA, dim);

            auto* data = new SolverData();
            data->t = t;
            data->ilw = ilw;
            data->ilm = ilm;
            data->iL = iL;
            data->iP = iP;
            data->Kw = Kw;
            data->Km = Km;
            data->M = M_resources;
            data->EVw_next = EVw_next;
            data->EVm_next = EVm_next;
            data->sol = sol;
            data->par = par;
            
            nlopt_set_min_objective(opt, objfunc_couple_to_couple, data);
            nlopt_set_xtol_rel(opt, XTOL);

            lb[0] = 1.0e-6;
            ub[0] = data->M - 1.0e-6;
            if (ub[0] < lb[0]) ub[0] = lb[0];
            nlopt_set_lower_bounds(opt, lb);
            nlopt_set_upper_bounds(opt, ub);

            // clamp starting value into the bounds
            if (starting_val < lb[0]) starting_val = lb[0];
            if (starting_val > ub[0]) starting_val = ub[0];
            x[0] = starting_val;

            // first optimization run
            double minf_global = 0.0;
            nlopt_optimize(opt, x, &minf_global);
            C_tot = x[0];

            // second optimizatoin run with a different starting value for multistart
            if (par->do_multistart) {
                double minf_local = 0.0;
                x[0] = starting_val * 0.5;
                nlopt_optimize(opt, x, &minf_local);
                if (minf_local < minf_global) {
                    C_tot = x[0];
                    minf_global = minf_local;
                }
                
            }
            
            // cleanup
            nlopt_destroy(opt);
            delete data;
        }

        // Recompute implied allocation for chosen C_tot
        double _ = value_of_choice_couple_to_couple(Cw_priv, Cm_priv, hw, hm, C_inter, Q,
            ilw, ilm, C_tot, Kw, Km, M_resources, t, iL, iP, Vw, Vm, EVw_next, EVm_next, par, sol);
    }

    void solve_couple_to_couple_Agrid_vfi(
        int t, int type_w, int type_m, int ilw, int ilm, int iP, int iL,int iKw, int iKm,
        double* EVw_next, double* EVm_next, sol_struct* sol, par_struct* par)
    {
        double labor_w = par->grid_l[ilw];
        double labor_m = par->grid_l[ilm];
        double Kw = par->grid_Kw[iKw];
        double Km = par->grid_Km[iKm];

        auto idx_d_A = index::couple_d(t, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, 0, par);

        double* Cwd_priv = &sol->Cwd_priv_couple_to_couple[idx_d_A];
        double* Cmd_priv = &sol->Cmd_priv_couple_to_couple[idx_d_A];
        double* hwd = &sol->hwd_couple_to_couple[idx_d_A];
        double* hmd = &sol->hmd_couple_to_couple[idx_d_A];
        double* Cd_inter = &sol->Cd_inter_couple_to_couple[idx_d_A];
        double* Qd = &sol->Qd_couple_to_couple[idx_d_A];
        double* Vwd = &sol->Vwd_couple_to_couple[idx_d_A];
        double* Vmd = &sol->Vmd_couple_to_couple[idx_d_A];
        double* Cd_tot = &sol->Cd_tot_couple_to_couple[idx_d_A];

        for (int iA = 0; iA < par->num_A; iA++) {
            double M_resources = resources_couple(type_w, type_m, labor_w, labor_m, par->grid_Kw[iKw], par->grid_Km[iKm], par->grid_A[iA], par);

            // starting values
            double starting_val = M_resources * 0.8;
            if (iA > 0) {
                starting_val = Cwd_priv[iA - 1] + Cmd_priv[iA - 1] + Cd_inter[iA - 1];
            }

            solve_couple_to_couple_step(&Cwd_priv[iA], &Cmd_priv[iA], &hwd[iA], &hmd[iA], &Cd_inter[iA], &Qd[iA],
            &Vwd[iA], &Vmd[iA], Kw, Km, M_resources, t, ilw, ilm, iL, iP, EVw_next, EVm_next, starting_val, sol, par);

            Cd_tot[iA] = Cwd_priv[iA] + Cmd_priv[iA] + Cd_inter[iA];
        }
    }

    ////////////////////////////// EGM numerical solution //////////////////////////////
    double marg_util_C_couple(double C_tot, int ilw, int ilm, int iP, par_struct* par, sol_struct* sol)
    {
        const double delta = 1.0e-4;
        double util = precompute::util_C_couple(C_tot, ilw, ilm, iP, 0.0, par, sol, par->precompute_intratemporal);
        double util_delta = precompute::util_C_couple(C_tot + delta, ilw, ilm, iP, 0.0, par, sol, par->precompute_intratemporal);
        return (util_delta - util) / delta;
    }

    // numerical inverse marginal utility
    struct SolverInvData {
        int ilw;
        int ilm;
        double margU;
        int iP;
        par_struct* par;
        sol_struct* sol;
        bool do_print;
    };

    double obj_inv_marg_util_couple(unsigned /*n*/, const double* x, double* /*grad*/, void* solver_data_in) {
        auto* d = static_cast<SolverInvData*>(solver_data_in);
        double C_tot = x[0];

        double penalty = 0.0;
        if (C_tot <= 0.0) {
            penalty += 1000.0 * C_tot * C_tot;
            C_tot = 1.0e-6;
        }

        double diff = marg_util_C_couple(C_tot, d->ilw, d->ilm, d->iP, d->par, d->sol) - d->margU;

        if (d->do_print) {
            logs::write("inverse_log.txt", 1, "C_tot: %f, diff: %f, penalty: %f\n", C_tot, diff, penalty);
        }
        return diff * diff + penalty;
    }

    double inv_marg_util_couple(double margU, int ilw, int ilm, int iP, par_struct* par, sol_struct* sol,
        double guess_Ctot, bool do_print = false)
    {
        auto* data = new SolverInvData();
        data->ilw = ilw; data->ilm = ilm; data->margU = margU; data->iP = iP;
        data->par = par; data->sol = sol; data->do_print = do_print;

        const int dim = 1;
        double lb[dim], ub[dim];
        double x[dim] = { guess_Ctot };


        auto opt = nlopt_create(NLOPT_LN_BOBYQA, dim);

        if (do_print) logs::write("inverse_log.txt", 0, "margU: %f\n", margU);

        nlopt_set_min_objective(opt, obj_inv_marg_util_couple, data);
        nlopt_set_xtol_rel(opt, XTOL);

        lb[0] = 0.0;
        ub[0] = 2.0 * par->max_Ctot;
        nlopt_set_lower_bounds(opt, lb);
        nlopt_set_upper_bounds(opt, ub);

        // first optimization run
        double minf_global = 0.0;
        nlopt_optimize(opt, x, &minf_global);
        double C_tot = x[0];

        // second optimization run with a different starting value for multistart
        if (par->do_multistart) {
            double minf_local = 0.0;
            x[0] = guess_Ctot * 0.5;
            nlopt_optimize(opt, x, &minf_local);
            if (minf_local < minf_global) {
                C_tot = x[0];
                minf_global = minf_local;
            }
            
        }

        // cleanup
        nlopt_destroy(opt);
        delete data;

        return C_tot;
    }


    //////////////////
    // EGM solution
    void interpolate_to_exogenous_grid_couple(
        int t, int type_w, int type_m, int ilw, int ilm, int iP, int iL,int iKw, int iKm,
        double* m_vec, double* c_vec, double* v_vec, double* EmargUd_pd,
        double* C_tot, double* Cw_priv, double* Cm_priv, double* hw, double* hm,
        double* C_inter, double* Q, double* Vw, double* Vm,
        double* EVw_next, double* EVm_next, double* V,
        sol_struct* sol, par_struct* par)
    {
        double Kw = par->grid_Kw[iKw];
        double Km = par->grid_Km[iKm];

        // Loop over exogenous asset grid
        for (int iA = 0; iA < par->num_A; iA++) {
            double M_now = resources_couple(type_w, type_m, par->grid_l[ilw], par->grid_l[ilm], par->grid_Kw[iKw], par->grid_Km[iKm], par->grid_A[iA], par);

            // If liquidity constraint binds, consume all resources
            if (M_now < m_vec[0]) {
                C_tot[iA] = M_now;
                value_of_choice_couple_to_couple(&Cw_priv[iA], &Cm_priv[iA], &hw[iA], &hm[iA], &C_inter[iA], &Q[iA],
                    ilw, ilm, C_tot[iA], Kw, Km, M_now, t, iL, iP, &Vw[iA], &Vm[iA], EVw_next, EVm_next, par, sol);

                double power = par->grid_power[iP];
                V[iA] = power * Vw[iA] + (1.0 - power) * Vm[iA];
                continue;
            }

            // Otherwise, search for the correct interval in the endogenous grid
            for (int iA_pd = 0; iA_pd < par->num_A_pd - 1; iA_pd++) {
                double m_low = m_vec[iA_pd];
                double m_high = m_vec[iA_pd + 1];

                bool in_interval = (M_now >= m_low) && (M_now <= m_high);
                bool extrap_above = (iA_pd == par->num_A_pd - 2) && (M_now > m_vec[par->num_A_pd - 1]);

                if (in_interval || extrap_above) {
                    // Endogenous grid points
                    double A_low = par->grid_A_pd[iA_pd];
                    double A_high = par->grid_A_pd[iA_pd + 1];

                    double V_low = v_vec[iA_pd];
                    double V_high = v_vec[iA_pd + 1];

                    double c_low = c_vec[iA_pd];
                    double c_high = c_vec[iA_pd + 1];

                    // Linear interpolation slopes
                    double v_slope = (V_high - V_low) / (A_high - A_low);
                    double c_slope = (c_high - c_low) / (m_high - m_low);

                    // Interpolated guesses
                    double c_guess = c_low + c_slope * (M_now - m_low);
                    double a_guess = M_now - c_guess;
                    double V_guess = V_low + v_slope * (a_guess - A_low);

                    // Upper envelope: only update if value is higher
                    if (V_guess > V[iA]) {
                        C_tot[iA] = c_guess;

                        value_of_choice_couple_to_couple(
                            &Cw_priv[iA], &Cm_priv[iA], &hw[iA], &hm[iA], &C_inter[iA], &Q[iA],
                            ilw, ilm, C_tot[iA], Kw, Km, M_now, t, iL, iP,
                            &Vw[iA], &Vm[iA], EVw_next, EVm_next, par, sol
                        );

                        double power = par->grid_power[iP];
                        V[iA] = power * Vw[iA] + (1.0 - power) * Vm[iA];
                    }
                }
            }
        }
    }

    void solve_couple_to_couple_Agrid_egm(
        int t, int type_w, int type_m, int ilw, int ilm, int iP, int iL,int iKw, int iKm,
        double* EVw_next, double* EVm_next, double* EmargV_next, sol_struct* sol, par_struct* par)
    {
        double Cw_priv = 0.0, Cm_priv = 0.0, hw = 0.0, hm = 0.0, C_inter = 0.0, Q = 0.0, Vw = 0.0, Vm = 0.0;

        auto idx_A_pd      = index::couple_pd(t,     type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, 0, par);
        auto idx_A_pd_next = index::couple_pd(t + 1, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, 0, par);

        double* EmargUd_pd = &sol->EmargUd_pd[idx_A_pd];
        double* Cd_tot_pd = &sol->Cd_tot_pd[idx_A_pd];
        double* Cd_tot_pd_next = &sol->Cd_tot_pd[idx_A_pd_next];
        double* Md_pd = &sol->Md_pd[idx_A_pd];
        double* Vd_couple_to_couple_pd = &sol->Vd_couple_to_couple_pd[idx_A_pd];

        double labor_w = par->grid_l[ilw];
        double labor_m = par->grid_l[ilm];
        double Kw = par->grid_Kw[iKw];
        double Km = par->grid_Km[iKm];
        double Kw_next = utils::human_capital_transition(Kw, par->grid_l[ilw], par);
        double Km_next = utils::human_capital_transition(Km, par->grid_l[ilm], par);

        // Loop over endogenous asset grid
        for (int iA_pd = 0; iA_pd < par->num_A_pd; ++iA_pd) {
            double A_next = par->grid_A_pd[iA_pd];

            EmargUd_pd[iA_pd] = par->beta * tools::interp_3d(par->grid_Kw, par->grid_Km, par->grid_A, par->num_K, par->num_K, par->num_A, EmargV_next, Kw_next, Km_next, A_next);

            if (strcmp(par->interp_method, "numerical") == 0) {

                // starting value: closed-form CRRA inverse-marginal-utility guess (C_tot ~ 3*C_priv)
                double rho_approx = 0.5 * (par->rho_w + par->rho_m);
                double guess_Ctot = 3.0 * pow(tools::max(EmargUd_pd[iA_pd], 1.0e-8), -1.0 / rho_approx);
                guess_Ctot = tools::max(tools::min(guess_Ctot, 2.0 * par->max_Ctot), 1.0e-4);

                Cd_tot_pd[iA_pd] = inv_marg_util_couple(EmargUd_pd[iA_pd], ilw, ilm, iP, par, sol, guess_Ctot);
            } else {
                if (strcmp(par->interp_method, "linear") == 0) {
                    auto idx_interp = index::index4(ilw, ilm, iP, 0, par->num_l, par->num_l, par->num_power, par->num_marg_u);
                    Cd_tot_pd[iA_pd] = tools::interp_1d(&sol->grid_marg_u_couple_for_inv[idx_interp], par->num_marg_u, par->grid_inv_marg_u, EmargUd_pd[iA_pd]);
                }

                if (par->interp_inverse) { // if the grid is for inverse marginal utility, invert it back to get consumption
                    Cd_tot_pd[iA_pd] = 1.0 / Cd_tot_pd[iA_pd];
                }
                // clamp the final consumption to ensure non-negativity and not exceeding total resources
                Cd_tot_pd[iA_pd] = tools::max(Cd_tot_pd[iA_pd], 0.0);
            }

            // Get endogenous grid points
            Md_pd[iA_pd] = A_next + Cd_tot_pd[iA_pd];

            // v. Get post-choice value (also updates the intra-period allocation)
            Vd_couple_to_couple_pd[iA_pd] = value_of_choice_couple_to_couple(
                &Cw_priv, &Cm_priv, &hw, &hm, &C_inter, &Q,
                ilw, ilm, Cd_tot_pd[iA_pd], Kw, Km, Md_pd[iA_pd], t, iL, iP,
                &Vw, &Vm, EVw_next, EVm_next,
                par, sol
            );
        }

        // Apply liquidity constraint and upper envelope while interpolating onto common grid
        auto idx_d_A = index::couple_d(t, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, 0, par);
        interpolate_to_exogenous_grid_couple(
            t, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm,
            &sol->Md_pd[idx_A_pd], &sol->Cd_tot_pd[idx_A_pd], &sol->Vd_couple_to_couple_pd[idx_A_pd],
            &sol->EmargUd_pd[idx_A_pd], &sol->Cd_tot_couple_to_couple[idx_d_A],
            &sol->Cwd_priv_couple_to_couple[idx_d_A], &sol->Cmd_priv_couple_to_couple[idx_d_A],
            &sol->hwd_couple_to_couple[idx_d_A], &sol->hmd_couple_to_couple[idx_d_A],
            &sol->Cd_inter_couple_to_couple[idx_d_A], &sol->Qd_couple_to_couple[idx_d_A],
            &sol->Vwd_couple_to_couple[idx_d_A], &sol->Vmd_couple_to_couple[idx_d_A],
            EVw_next, EVm_next, &sol->Vd_couple_to_couple[idx_d_A],
            sol, par
        );
    }

    void calc_marginal_value_couple_Agrid(double power, double* Vw, double* Vm, double* margV, sol_struct* sol, par_struct* par)
    {
        if (par->centered_gradient) {
            for (int iA = 1; iA < par->num_A - 1; ++iA) {
                int iA_plus = iA + 1;
                int iA_minus = iA - 1;
                double denom = 1.0 / (par->grid_A[iA_plus] - par->grid_A[iA_minus]);
                double margVw = Vw[iA_plus] * denom - Vw[iA_minus] * denom;
                double margVm = Vm[iA_plus] * denom - Vm[iA_minus] * denom;
                margV[iA] = power * margVw + (1.0 - power) * margVm;
                if (iA == par->num_A - 2) margV[iA_plus] = margV[iA];
            }

            margV[0] = (margV[2] - margV[1]) / (par->grid_A[2] - par->grid_A[1]) * (par->grid_A[0] - par->grid_A[1]) + margV[1];
            int i = par->num_A - 1;
            margV[i] = (margV[i - 2] - margV[i - 1]) / (par->grid_A[i - 2] - par->grid_A[i - 1]) * (par->grid_A[i] - par->grid_A[i - 1]) + margV[i - 1];
        } else {
            for (int iA = 0; iA < par->num_A - 1; ++iA) {
                int iA_plus = iA + 1;
                double denom = 1.0 / (par->grid_A[iA_plus] - par->grid_A[iA]);
                double margVw = Vw[iA_plus] * denom - Vw[iA] * denom;
                double margVm = Vm[iA_plus] * denom - Vm[iA] * denom;
                margV[iA] = power * margVw + (1.0 - power) * margVm;
                if (iA == par->num_A - 2) margV[iA_plus] = margV[iA];
            }
        }
    }

    void update_optimal_discrete_solution_couple_Agrid(
        int t, int type_w, int type_m, int ilw, int ilm, int iP, int iL,int iKw, int iKm,
        sol_struct* sol, par_struct* par)
    {
        auto idx_A   = index::couple(t, type_w, type_m, iP, iL, iKw, iKm, 0, par);
        auto idx_d_A = index::couple_d(t, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, 0, par);

        double power = par->grid_power[iP];
        double* Vwd_couple_to_couple = &sol->Vwd_couple_to_couple[idx_d_A];
        double* Vmd_couple_to_couple = &sol->Vmd_couple_to_couple[idx_d_A];
        double* V_couple_to_couple = &sol->V_couple_to_couple[idx_A];
        double* Vw_couple_to_couple = &sol->Vw_couple_to_couple[idx_A];
        double* Vm_couple_to_couple = &sol->Vm_couple_to_couple[idx_A];
        double* lw_couple_to_couple = &sol->lw_couple_to_couple[idx_A];
        double* lm_couple_to_couple = &sol->lm_couple_to_couple[idx_A];

        for (int iA = 0; iA < par->num_A; ++iA) {
            double Vd_now = power * Vwd_couple_to_couple[iA] + (1.0 - power) * Vmd_couple_to_couple[iA];
            if (V_couple_to_couple[iA] < Vd_now) {
                V_couple_to_couple[iA] = Vd_now;
                Vw_couple_to_couple[iA] = Vwd_couple_to_couple[iA];
                Vm_couple_to_couple[iA] = Vmd_couple_to_couple[iA];
                lw_couple_to_couple[iA] = par->grid_l[ilw];
                lm_couple_to_couple[iA] = par->grid_l[ilm];
            }
        }
    }

    void solve_choice_specific_couple_to_couple(
        int t, int type_w, int type_m, int iP, int iL, int iKw, int iKm, int ilw, int ilm,
        sol_struct* sol, par_struct* par)
    {
        if (t == (par->T - 1)) {
            solve_couple_to_couple_Agrid_vfi(t, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, nullptr, nullptr, sol, par);
        } else {
            auto idx_next = index::couple(t + 1, type_w, type_m, iP, iL, 0, 0, 0, par);
            double* EVw_next    = &sol->EVw_start_as_couple[idx_next];
            double* EVm_next    = &sol->EVm_start_as_couple[idx_next];
            double* EmargV_next = &sol->EmargV_start_as_couple[idx_next];

            if (par->do_egm) {
                solve_couple_to_couple_Agrid_egm(t, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, EVw_next, EVm_next, EmargV_next, sol, par);
            } else {
                solve_couple_to_couple_Agrid_vfi(t, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, EVw_next, EVm_next, sol, par);
            }
        }

        update_optimal_discrete_solution_couple_Agrid(t, type_w, type_m, ilw, ilm, iP, iL, iKw, iKm, sol, par);
    }

    void solve_couple(int t, sol_struct* sol, par_struct* par)
    {

        const int nP  = par->num_power;
        const int nL  = par->num_love;
        const int ntypes  = par->num_types;
        const int nK  = par->num_K;
        const long long total = ntypes * ntypes * nP * nL * nK * nK;

        #pragma omp for schedule(static)
        for (long long idx = 0; idx < total; ++idx) {

            const auto type_w = par->idx_couple_type_w[idx];
            const auto type_m = par->idx_couple_type_m[idx];
            const auto iP = par->idx_couple_power[idx];
            const auto iL = par->idx_couple_love[idx];
            const auto iKw = par->idx_couple_Kw[idx];
            const auto iKm = par->idx_couple_Km[idx];

            // Note: important to have discrete choice as inner loop
            //       to allow parallelization over outer loops while
            //       making the optimal choice of discrete choice
            //       thread-safe
            for (int ilw = 0; ilw < par->num_l; ++ilw) {
                for (int ilm = 0; ilm < par->num_l; ++ilm) {
                    solve_choice_specific_couple_to_couple(t, type_w, type_m, iP, iL, iKw, iKm, ilw, ilm, sol, par);
                }
            }
        }
    }

    double calc_marital_surplus(double Vd_couple_to_couple, double V_couple_to_single) {
        return Vd_couple_to_couple - V_couple_to_single;
    }

    void solve_start_as_couple_full_commit(
        int t, int type_w, int type_m, int iL, int iKw, int iKm, int iA,
        sol_struct* sol, par_struct* par)
    {
        for (int iP = 0; iP < par->num_power; ++iP) {
            auto idx_couple = index::couple(t, type_w, type_m, iP, iL, iKw, iKm, iA, par);
            sol->Vw_start_as_couple[idx_couple] = sol->Vw_couple_to_couple[idx_couple];
            sol->Vm_start_as_couple[idx_couple] = sol->Vm_couple_to_couple[idx_couple];
            sol->power_idx[idx_couple] = iP;
            sol->power[idx_couple] = par->grid_power[iP];
        }
    }

    void solve_start_as_couple_powergrid(
        int t, int type_w, int type_m, int iL, int iKw, int iKm, int iA,
        sol_struct* sol, par_struct* par)
    {
        const int num = 2;
        double** list_start_as_couple = new double*[num];
        double** list_couple_to_couple = new double*[num];
        double* list_couple_to_single = new double[num];

        double* surplus_w = new double[par->num_power];
        double* surplus_m = new double[par->num_power];

        auto* idx_couple_fct = new index::index_couple_struct;

        auto idx_single_w = index::single(t, type_w, iKw, iA, par);
        auto idx_single_m = index::single(t, type_m, iKm, iA, par);

        idx_couple_fct->t = t;
        idx_couple_fct->type_w = type_w;
        idx_couple_fct->type_m = type_m;
        idx_couple_fct->iL = iL;
        idx_couple_fct->iKw = iKw;
        idx_couple_fct->iKm = iKm;
        idx_couple_fct->iA = iA;
        idx_couple_fct->par = par;

        for (int iP = 0; iP < par->num_power; ++iP) {
            auto idx_couple = index::couple(t, type_w, type_m, iP, iL, iKw, iKm, iA, par);
            surplus_w[iP] = calc_marital_surplus(sol->Vw_couple_to_couple[idx_couple], sol->Vw_couple_to_single[idx_single_w]);
            surplus_m[iP] = calc_marital_surplus(sol->Vm_couple_to_couple[idx_couple], sol->Vm_couple_to_single[idx_single_m]);
        }

        list_start_as_couple[0] = sol->Vw_start_as_couple;
        list_start_as_couple[1] = sol->Vm_start_as_couple;
        list_couple_to_couple[0] = sol->Vw_couple_to_couple;
        list_couple_to_couple[1] = sol->Vm_couple_to_couple;
        list_couple_to_single[0] = sol->Vw_couple_to_single[idx_single_w];
        list_couple_to_single[1] = sol->Vm_couple_to_single[idx_single_m];

        // update solutions in list_start_as_couple
        bargaining::check_participation_constraints(sol->power_idx, sol->power, surplus_w, surplus_m, idx_couple_fct,
            list_start_as_couple, list_couple_to_couple, list_couple_to_single, num, par);

        delete[] list_start_as_couple;
        delete[] list_couple_to_couple;
        delete[] list_couple_to_single;
        delete[] surplus_w;
        delete[] surplus_m;
        delete idx_couple_fct;
    }

    void calc_expected_value_couple(
        int t, int type_w, int type_m, int iP, int iL, int iKw, int iKm, int iA,
        double* Vw, double* Vm, double* EVw, double* EVm,
        sol_struct* /*sol*/, par_struct* par)
    {
        double love = par->grid_love[iL];
        double Kw = par->grid_Kw[iKw];
        double Km = par->grid_Km[iKm];
        auto idx = index::couple(t, type_w, type_m, iP, iL, iKw, iKm, iA, par);

        double Eval_w = 0.0;
        double Eval_m = 0.0;

        // Note: A is on grid, but can't interpolate from last point. Use iA as index for interpolation, except if last point
        auto idx_A = iA;
        if (idx_A == par->num_A - 1) {
            idx_A = par->num_A - 2;
        }

        for (int i_love_shock = 0; i_love_shock < par->num_shock_love; ++i_love_shock) {
            double love_shock = love + par->grid_shock_love[i_love_shock];
            love_shock = tools::max(par->grid_love[0], tools::min(love_shock, par->grid_love[par->num_love-1]));
            double weight_love = par->grid_weight_love[i_love_shock];
            auto idx_love = tools::binary_search(0, par->num_love, par->grid_love, love_shock);
            for (int iKw_shock = 0; iKw_shock < par->num_shock_K; ++iKw_shock) {
                double Kw_shock = par->grid_shock_Kw[iKw_shock] * Kw;
                Kw_shock = tools::max(0.0, tools::min(Kw_shock, par->max_K)); // ensure shocks don't push outside grid bounds
                double weight_Kw = par->grid_weight_Kw[iKw_shock];
                auto idx_Kw = tools::binary_search(0, par->num_K, par->grid_Kw, Kw_shock);
                for (int iKm_shock = 0; iKm_shock < par->num_shock_K; ++iKm_shock) {
                    double Km_shock = par->grid_shock_Km[iKm_shock] * Km;
                    Km_shock = tools::max(0.0, tools::min(Km_shock, par->max_K)); // ensure shocks don't push outside grid bounds
                    double weight_Km = par->grid_weight_Km[iKm_shock];
                    auto idx_Km = tools::binary_search(0, par->num_K, par->grid_Km, Km_shock);
                    
                    
                    auto idx_interp = index::couple(t, type_w, type_m, iP, 0, 0, 0, 0, par);
                    double Vw_now = tools::_interp_4d_index(
                        par->grid_love, par->grid_Kw,par->grid_Km,par->grid_A,
                        par->num_love, par->num_K, par->num_K, par->num_A,
                        &Vw[idx_interp],
                        love_shock, Kw_shock, Km_shock, par->grid_A[iA],
                        idx_love, idx_Kw, idx_Km, idx_A
                    );
                    double Vm_now = tools::_interp_4d_index(
                        par->grid_love, par->grid_Kw,par->grid_Km,par->grid_A,
                        par->num_love, par->num_K, par->num_K, par->num_A,
                        &Vm[idx_interp],
                        love_shock, Kw_shock, Km_shock, par->grid_A[iA],
                        idx_love, idx_Kw, idx_Km, idx_A
                    );

                    double weight = weight_love * weight_Kw * weight_Km;
                    Eval_w += weight * Vw_now;
                    Eval_m += weight * Vm_now;
                }
            }
        }

        EVw[idx] = Eval_w;
        EVm[idx] = Eval_m;
    }

    void expected_value_start_couple(int t, sol_struct* sol, par_struct* par)
    {
        const int nP  = par->num_power;
        const int nL  = par->num_love;
        const int ntypes  = par->num_types;
        const int nK  = par->num_K;
        long long total = ntypes * ntypes * nL * nK * nK;

        #pragma omp for schedule(static)
        for (long long idx = 0; idx < total; ++idx) {

            const auto type_w = par->idx_couple_barg_type_w[idx];
            const auto type_m = par->idx_couple_barg_type_m[idx];
            const auto iL = par->idx_couple_barg_love[idx];
            const auto iKw = par->idx_couple_barg_Kw[idx];
            const auto iKm = par->idx_couple_barg_Km[idx];

            for (int iA = 0; iA < par->num_A; ++iA) {
                if (strcmp(par->bargaining, "limited") == 0) {
                    solve_start_as_couple_powergrid(t, type_w, type_m, iL, iKw, iKm, iA, sol, par);
                } else if (strcmp(par->bargaining, "full") == 0) {
                    solve_start_as_couple_full_commit(t, type_w, type_m, iL, iKw, iKm, iA, sol, par);
                } else {
                    logs::write("error_log.txt", 1, "Error: Invalid bargaining type '%s'\n", par->bargaining);
                    exit(1);
                }
            }
        }


        total = ntypes * ntypes * nP * nL * nK * nK;
            
        #pragma omp for schedule(static)
        for (long long idx = 0; idx < total; ++idx) {

            const auto type_w = par->idx_couple_type_w[idx];
            const auto type_m = par->idx_couple_type_m[idx];
            const auto iP = par->idx_couple_power[idx];
            const auto iL = par->idx_couple_love[idx];
            const auto iKw = par->idx_couple_Kw[idx];
            const auto iKm = par->idx_couple_Km[idx];

            for (int iA = 0; iA < par->num_A; ++iA) {
                calc_expected_value_couple(
                    t, type_w, type_m, iP, iL, iKw, iKm, iA,
                    sol->Vw_start_as_couple, sol->Vm_start_as_couple,
                    sol->EVw_start_as_couple, sol->EVm_start_as_couple,
                    sol, par
                );
            }

            if (par->do_egm) {
                auto idx_A = index::couple(t, type_w, type_m, iP, iL, iKw, iKm, 0, par);
                double power = par->grid_power[iP];
                calc_marginal_value_couple_Agrid(
                    power,
                    &sol->EVw_start_as_couple[idx_A], &sol->EVm_start_as_couple[idx_A],
                    &sol->EmargV_start_as_couple[idx_A],
                    sol, par
                );
            }
        }
    }

    void solve_single_to_couple(int t, sol_struct* sol, par_struct* par) {
        const int nP  = par->num_power;
        const int nL  = par->num_love;
        const int ntypes  = par->num_types;
        const int nK  = par->num_K;
        const long long total = ntypes * ntypes * nP * nL * nK * nK;
            
        #pragma omp for schedule(static)
        for (long long idx = 0; idx < total; ++idx) {

            const auto type_w = par->idx_couple_type_w[idx];
            const auto type_m = par->idx_couple_type_m[idx];
            const auto iP = par->idx_couple_power[idx];
            const auto iL = par->idx_couple_love[idx];
            const auto iKw = par->idx_couple_Kw[idx];
            const auto iKm = par->idx_couple_Km[idx];

            auto idx_A = index::couple(t, type_w, type_m, iP, iL, iKw, iKm, 0, par);

            double* Vw_single_to_couple = &sol->Vw_single_to_couple[idx_A];
            double* Vm_single_to_couple = &sol->Vm_single_to_couple[idx_A];
            double* Vw_couple_to_couple = &sol->Vw_couple_to_couple[idx_A];
            double* Vm_couple_to_couple = &sol->Vm_couple_to_couple[idx_A];

            for (int iA = 0; iA < par->num_A; ++iA) {
                Vw_single_to_couple[iA] = Vw_couple_to_couple[iA];
                Vm_single_to_couple[iA] = Vm_couple_to_couple[iA];
            }
        }
    }

}
