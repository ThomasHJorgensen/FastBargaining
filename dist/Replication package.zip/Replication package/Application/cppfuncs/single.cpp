#ifndef MAIN
#define SINGLE
#include "myheader.cpp"
#endif

namespace single {

    // Data passed to the single-agent objective solver
    struct SolverSingleData {
        int t;
        int type;
        int il;
        double K;
        double M;
        double* EV_next;
        int gender;
        par_struct* par;
        sol_struct* sol;
    };

    // Small constant to avoid exact-zero resources
    static constexpr double RESOURCES_EPS = 1.0e-4;

    
    double tax_single(double income, par_struct* par) {

        // Define brackets and their rates in one place
        // Each row: {bracket top, rate applied up to that top}
        int    num_brackets     = 5;
        double bracket_tops[5]  = {26250.0, 63550.0, 132600.0, 288350.0, 1e308};
        // double bracket_rates[5] = {20.0, 20.0, 20.0, 20.0, 20.0};
        double bracket_rates[5] = {15.0, 28.0, 31.0, 36.0, 39.6};
        
        for (int i = 0; i < num_brackets; i++) {
            bracket_tops[i] = bracket_tops[i] / par->money_metric;
            bracket_rates[i] = bracket_rates[i] / 100.0;
        }


        double tax        = 0.0;
        double prev_top   = 0.0;

        for (int i = 0; i < num_brackets; i++) {
            double bracket_income = 0.0;
            if (income <= bracket_tops[i]) {
                bracket_income = income - prev_top;
                tax += bracket_income * bracket_rates[i];
                return tax;
            }
            bracket_income = bracket_tops[i] - prev_top;
            tax += bracket_income * bracket_rates[i];
            prev_top = bracket_tops[i];
        }

        return tax;

    }

    double after_tax_income_single(int type, double labor, double K, double A, int gender, par_struct* par) {
        if (labor == 0.0) return RESOURCES_EPS + (par->R - 1.0) * A;

        double gross_wage_income = utils::wage_income(type, labor, K, gender, par);

        // income floor
        if (gross_wage_income < 0.0001) { 
            gross_wage_income = 0.0001;
        }
        double tax = tax_single(gross_wage_income, par);
        return gross_wage_income - tax + (par->R - 1.0) * A;
    }

    double resources_single(int type, double labor, double K, double A, int gender, par_struct* par) {
        double after_tax_income = after_tax_income_single(type, labor, K, A, gender, par);
        return A + after_tax_income; // note that interest rates of A are included in after_tax_income
    }

    double value_of_choice_single_to_single(double* C_priv, double* h, double* C_inter, double* Q,
                                            double C_tot, int t, int il, double K, double M, int gender,
                                            double* V_next, par_struct* par, sol_struct* sol) {
        const double labor = par->grid_l[il];

        // intraperiod allocation: fills C_priv, h, C_inter, Q
        precompute::intraperiod_allocation_single(C_priv, h, C_inter, Q, C_tot, il, gender, par, sol,
                                                par->precompute_intratemporal);

        double total_hours = *h + labor;
        double util = utils::util(*C_priv, total_hours, *Q, gender, par, 0.0);

        double continuation = 0.0;
        if (t < (par->T - 1)) {
            double* grid_A = (gender == man) ? par->grid_Am : par->grid_Aw;
            double* grid_K = (gender == man) ? par->grid_Km : par->grid_Kw;
            double A_next = M - C_tot;
            double K_next = utils::human_capital_transition(K, labor, par);
            continuation = tools::interp_2d(grid_K, grid_A, par->num_K, par->num_A, V_next, K_next, A_next);
        }

        return util + par->beta * continuation;
    }

    double objfunc_single_to_single(unsigned /*n*/, const double* x, double* /*grad*/, void* solver_data_in) {
        auto* data = static_cast<SolverSingleData*>(solver_data_in);

        double C_tot = x[0];
        int t = data->t;
        int type = data->type;
        int il = data->il;
        int gender = data->gender;
        double K = data->K;
        double M = data->M;
        double* EV_next = data->EV_next;
        par_struct* par = data->par;
        sol_struct* sol = data->sol;

        // intraperiod outputs
        double C_priv = 0.0, h = 0.0, C_inter = 0.0, Q = 0.0;

        // Clamp C_tot to (tiny, M)
        constexpr double C_TINY = 1.0e-12;
        if (C_tot < C_TINY) C_tot = C_TINY;
        if (C_tot > M) C_tot = M;

        // optimizer minimizes -> return negative value
        return -value_of_choice_single_to_single(&C_priv, &h, &C_inter, &Q,
                                                C_tot, t, il, K, M, gender,
                                                EV_next, par, sol);
    }

    void solve_single_to_single_step(
        double* Cd_priv, double* hd, double* Cd_inter, double* Qd, double* Vd,
        double M_resources, int t, int type, int il, double K,
        double* EV_next,
        double starting_val, int gender, sol_struct* sol, par_struct* par
    ) {
        double Cd_tot = M_resources;

        if (t < (par->T - 1)) {
            // Setup solver data and optimizer
            SolverSingleData* solver_data = new SolverSingleData{t, type, il, K, M_resources, EV_next, gender, par, sol};

            constexpr int dim = 1;
            double lb[dim], ub[dim];
            double x[dim] = { starting_val };

            auto opt = nlopt_create(NLOPT_LN_BOBYQA, dim);

            nlopt_set_min_objective(opt, objfunc_single_to_single, solver_data);
            nlopt_set_xtol_rel(opt, XTOL);

            // bounds
            lb[0] = 1.0e-8;
            ub[0] = solver_data->M;
            if (ub[0] < lb[0]) ub[0] = lb[0];
            nlopt_set_lower_bounds(opt, lb);
            nlopt_set_upper_bounds(opt, ub);

            if (starting_val < lb[0]) starting_val = lb[0];
            if (starting_val > ub[0]) starting_val = ub[0];
            x[0] = starting_val;

            // first optimization run
            double minf_global = 0.0;
            nlopt_optimize(opt, x, &minf_global);
            Cd_tot = x[0];

            // second optimizatoin run with a different starting value for multistart
            if (par->do_multistart) {
                double minf_local = 0.0;
                x[0] = starting_val * 0.5;
                nlopt_optimize(opt, x, &minf_local);
                if (minf_local < minf_global) {
                    Cd_tot = x[0];
                    minf_global = minf_local;
                }
                
            }
            
            // cleanup
            nlopt_destroy(opt);
            delete solver_data;
        }

        // compute implied allocation and value
        *Vd = value_of_choice_single_to_single(Cd_priv, hd, Cd_inter, Qd, Cd_tot,
                                            t, il, K, M_resources, gender, EV_next, par, sol);
    }

    void solve_single_to_single_Agrid_vfi(int t, int type, int il, int iK, double* EV_next, int gender, sol_struct* sol, par_struct* par) {
        const double labor = par->grid_l[il];

        // get index
        auto idx_d_A = index::single_d(t, type, il, iK, 0, par);

        // pointers to storage (gender-specific)
        double* Cd_tot = &sol->Cwd_tot_single_to_single[idx_d_A];
        double* Cd_priv = &sol->Cwd_priv_single_to_single[idx_d_A];
        double* hd = &sol->hwd_single_to_single[idx_d_A];
        double* Cd_inter = &sol->Cwd_inter_single_to_single[idx_d_A];
        double* Qd = &sol->Qwd_single_to_single[idx_d_A];
        double* Vd = &sol->Vwd_single_to_single[idx_d_A];
        double* grid_A = par->grid_Aw;
        double* grid_K = par->grid_Kw;

        if (gender == man) {
            Cd_tot = &sol->Cmd_tot_single_to_single[idx_d_A];
            Cd_priv = &sol->Cmd_priv_single_to_single[idx_d_A];
            hd = &sol->hmd_single_to_single[idx_d_A];
            Cd_inter = &sol->Cmd_inter_single_to_single[idx_d_A];
            Qd = &sol->Qmd_single_to_single[idx_d_A];
            Vd = &sol->Vmd_single_to_single[idx_d_A];
            grid_A = par->grid_Am;
            grid_K = par->grid_Km;
        }

        for (int iA = 0; iA < par->num_A; iA++) {
            // resources depend on K and A
            const double K = grid_K[iK];
            const double A = grid_A[iA];
            double M_resources = resources_single(type, labor, K, A, gender, par);

            // starting value: previous solution or fraction of resources
            double starting_val = (iA > 0) ? Cd_tot[iA - 1] : (M_resources * 0.8);

            solve_single_to_single_step(&Cd_priv[iA], &hd[iA], &Cd_inter[iA], &Qd[iA], &Vd[iA],
                                    M_resources, t, type, il, K, EV_next, starting_val, gender, sol, par);

            Cd_tot[iA] = Cd_priv[iA] + Cd_inter[iA];
        } // iA

    }

        //////////////////// EGM ////////////////////////
        ////// numerical EGM //////
    double marg_util_C_single(double C_tot, int il, int gender, par_struct* par, sol_struct* sol) {
        double util = precompute::util_C_single(C_tot, il, gender, par, sol, par->precompute_intratemporal);
        constexpr double delta = 1.0e-4;
        double util_delta = precompute::util_C_single(C_tot + delta, il, gender, par, sol, par->precompute_intratemporal);
        return (util_delta - util) / delta;
    }

    struct SolverInvData {
        int il;
        double margU;
        int gender;
        par_struct* par;
        sol_struct* sol;
    };

    double obj_inv_marg_util_single(unsigned /*n*/, const double* x, double* /*grad*/, void* solver_data_in) {
        auto* d = static_cast<SolverInvData*>(solver_data_in);

        double C_tot = x[0];
        int il = d->il;
        double margU = d->margU;
        int gender = d->gender;
        par_struct* par = d->par;
        sol_struct* sol = d->sol;

        // clip and penalize non-positive consumption
        double penalty = 0.0;
        if (C_tot <= 0.0) {
            penalty += 1000.0 * C_tot * C_tot;
            C_tot = 1.0e-6;
        }

        double diff = marg_util_C_single(C_tot, il, gender, par, sol) - margU;
        return diff * diff + penalty;
    }

    double inv_marg_util_single(double margU, int il, int gender, par_struct* par, sol_struct* sol,
                                double guess_C_tot) {
        SolverInvData* data = new SolverInvData{il, margU, gender, par, sol};

        constexpr int dim = 1;
        double lb[dim], ub[dim];
        double x[dim] = { guess_C_tot };

        auto opt = nlopt_create(NLOPT_LN_BOBYQA, dim);

        nlopt_set_min_objective(opt, obj_inv_marg_util_single, data);
        nlopt_set_xtol_rel(opt, XTOL);

        lb[0] = 0.0;
        ub[0] = 2.0 * par->max_Ctot;
        nlopt_set_lower_bounds(opt, lb);
        nlopt_set_upper_bounds(opt, ub);

        // first optimization run
        double minf_global = 0.0;
        nlopt_optimize(opt, x, &minf_global);
        double C_tot = x[0];

        // second optimizatoin run with a different starting value for multistart
        if (par->do_multistart) {
            double minf_local = 0.0;
            x[0] = guess_C_tot * 0.5;
            nlopt_optimize(opt, x, &minf_local);
            if (minf_local < minf_global) {
                C_tot = x[0];
                minf_global = minf_local;
            }
            
        }

        // cleanup
        nlopt_destroy(opt);
        delete data;

        return C_tot;
    }


        /////// iEGM //////
    void interpolate_to_exogenous_grid_single(
        int t, int type, int il, int iK, int gender,
        double* m_vec, double* c_vec, double* v_vec,
        double* C_tot, double* C_priv, double* h, double* C_inter, double* Q, double* V,
        double* EV_next, sol_struct* sol, par_struct* par
    ) {
        double labor = par->grid_l[il];
        double* grid_A = (gender == man) ? par->grid_Am : par->grid_Aw;
        double* grid_A_pd = (gender == man) ? par->grid_Am_pd : par->grid_Aw_pd;
        double* grid_K = (gender == man) ? par->grid_Km : par->grid_Kw;

        const double K = grid_K[iK];

        // Loop over the common (exogenous) asset grid
        for (int iA = 0; iA < par->num_A; iA++) {
            double M_now = resources_single(type, labor, K, grid_A[iA], gender, par);

            // If liquidity constraint binds, consume all resources
            if (M_now < m_vec[0]) {
                C_tot[iA] = M_now;
                V[iA] = value_of_choice_single_to_single(&C_priv[iA], &h[iA], &C_inter[iA], &Q[iA],
                                                        C_tot[iA], t, il, K, M_now, gender, EV_next, par, sol);
                continue;
            }

            // Otherwise, search for the correct interval in the endogenous grid
            for (int iA_pd = 0; iA_pd < par->num_A_pd - 1; iA_pd++) {
                double m_low = m_vec[iA_pd];
                double m_high = m_vec[iA_pd + 1];

                bool in_interval = (M_now >= m_low && M_now <= m_high);
                bool extrapolate_above = (iA_pd == par->num_A_pd - 2 && M_now > m_vec[par->num_A_pd - 1]);

                if (in_interval || extrapolate_above) {
                    // Endogenous asset grid points
                    double A_low = grid_A_pd[iA_pd];
                    double A_high = grid_A_pd[iA_pd + 1];

                    // Value and consumption at interval endpoints
                    double V_low = v_vec[iA_pd];
                    double V_high = v_vec[iA_pd + 1];
                    double c_low = c_vec[iA_pd];
                    double c_high = c_vec[iA_pd + 1];

                    // Slopes for interpolation
                    double v_slope = (V_high - V_low) / (A_high - A_low);
                    double c_slope = (c_high - c_low) / (m_high - m_low);

                    // Interpolate consumption and assets
                    double c_guess = c_low + c_slope * (M_now - m_low);
                    double a_guess = M_now - c_guess;
                    double V_guess = V_low + v_slope * (a_guess - A_low);

                    // upper envelope
                    if (V_guess > V[iA]) {
                        C_tot[iA] = c_guess;
                        V[iA] = value_of_choice_single_to_single(&C_priv[iA], &h[iA], &C_inter[iA], &Q[iA],
                                                                C_tot[iA], t, il, K, M_now, gender, EV_next, par, sol);
                    } // if upper envelope
                } // if in_interval
            } // iA_pd
        } // iA
    }


    void solve_single_to_single_Agrid_egm(int t, int type, int il, int iK, int gender, sol_struct* sol, par_struct* par){
        // get index
        auto idx_A_pd  = index::single_pd(t, type, il, iK, 0, par);
        auto idx_A_pd_next = index::single_pd(t + 1, type, il, iK, 0, par);
        auto idx_d_A   = index::single_d(t, type, il, iK, 0, par);
        auto idx_next  = index::single(t + 1, type, 0, 0, par);
        auto idx_interp = index::index2(il, 0, par->num_l, par->num_marg_u);
        
        // 1. Setup: gender-specific pointers
        double* grid_A = par->grid_Aw;
        double* grid_A_pd = par->grid_Aw_pd;
        double* grid_K = par->grid_Kw;
        double* grid_marg_u_single_for_inv = sol->grid_marg_u_single_w_for_inv;
        double* V = sol->Vwd_single_to_single;
        double* EV = sol->EVw_start_as_single;
        double* margV = sol->EmargVw_start_as_single;
        double* C_tot = sol->Cwd_tot_single_to_single;
        double* C_priv = sol->Cwd_priv_single_to_single;
        double* h = sol->hwd_single_to_single;
        double* C_inter = sol->Cwd_inter_single_to_single;
        double* Q = sol->Qwd_single_to_single;
        double* EmargU_pd = &sol->EmargUwd_single_to_single_pd[idx_A_pd];
        double* C_tot_pd = &sol->Cwd_tot_single_to_single_pd[idx_A_pd];
        double* M_pd = &sol->Mwd_single_to_single_pd[idx_A_pd];
        double* V_pd = &sol->Vwd_single_to_single_pd[idx_A_pd];

        if (gender == man) {
            grid_A = par->grid_Am;
            grid_A_pd = par->grid_Am_pd;
            grid_K = par->grid_Km;
            grid_marg_u_single_for_inv = sol->grid_marg_u_single_m_for_inv;
            V = sol->Vmd_single_to_single;
            EV = sol->EVm_start_as_single;
            margV = sol->EmargVm_start_as_single;
            C_tot = sol->Cmd_tot_single_to_single;
            C_priv = sol->Cmd_priv_single_to_single;
            h = sol->hmd_single_to_single;
            C_inter = sol->Cmd_inter_single_to_single;
            Q = sol->Qmd_single_to_single;
            EmargU_pd = &sol->EmargUmd_single_to_single_pd[idx_A_pd];
            C_tot_pd = &sol->Cmd_tot_single_to_single_pd[idx_A_pd];
            M_pd = &sol->Mmd_single_to_single_pd[idx_A_pd];
            V_pd = &sol->Vmd_single_to_single_pd[idx_A_pd];
        }

        // placeholders 
        double C_priv_ph = 0;
        double h_ph = 0;
        double C_inter_ph = 0;
        double Q_ph = 0;


        // 2. EGM step
        int min_point_A = 0;
        double labor = par->grid_l[il];
        double K = grid_K[iK];
        double K_next = utils::human_capital_transition(K, par->grid_l[il], par);
        int min_point_K = tools::binary_search(0, par->num_K, grid_K, K_next);
        
        for (int iA_pd = 0; iA_pd < par->num_A_pd; iA_pd++) {
            double A_next = grid_A_pd[iA_pd];

            // expected marginal utility
            min_point_A = tools::binary_search(min_point_A, par->num_A, grid_A, A_next);
            EmargU_pd[iA_pd] = par->beta * tools::_interp_2d(grid_K, grid_A, par->num_K, par->num_A, &margV[idx_next], K_next, A_next, min_point_K, min_point_A);

            // invert marginal utility
            if (strcmp(par->interp_method, "numerical") == 0) {
                double rho_gender = (gender == man) ? par->rho_m : par->rho_w;
                double guess_C_tot = 2.0 * pow(tools::max(EmargU_pd[iA_pd], 1.0e-8), -1.0 / rho_gender);
                guess_C_tot = tools::max(tools::min(guess_C_tot, 2.0 * par->max_Ctot), 1.0e-4);
                C_tot_pd[iA_pd] = inv_marg_util_single(EmargU_pd[iA_pd], il, gender, par, sol, guess_C_tot);
            } else {
                if (strcmp(par->interp_method, "linear") == 0) {
                    C_tot_pd[iA_pd] = tools::interp_1d(&grid_marg_u_single_for_inv[idx_interp], par->num_marg_u, par->grid_inv_marg_u, EmargU_pd[iA_pd]);
                }
                if (par->interp_inverse) { // if the grid is for inverse marginal utility, invert it back to get consumption
                    C_tot_pd[iA_pd] = 1.0 / C_tot_pd[iA_pd];
                }
                C_tot_pd[iA_pd] = std::max(C_tot_pd[iA_pd], 0.0);
            }

            // endogenous grid over resources
            M_pd[iA_pd] = C_tot_pd[iA_pd] + A_next;

            // value at endogenous point
            V_pd[iA_pd] = value_of_choice_single_to_single(&C_priv_ph, &h_ph, &C_inter_ph, &Q_ph, C_tot_pd[iA_pd], t, il, K, M_pd[iA_pd], gender, &EV[idx_next], par, sol);
        }

        // 3. Apply liquidity constraint and upper envelope while interpolating onto common grid
        interpolate_to_exogenous_grid_single(
            t, type, il, iK, gender,
            M_pd, C_tot_pd, V_pd,
            &C_tot[idx_d_A], &C_priv[idx_d_A], &h[idx_d_A], &C_inter[idx_d_A], &Q[idx_d_A], &V[idx_d_A],
            &EV[idx_next], sol, par
        );
    }

    void calc_marginal_value_single_Agrid(double* V, double* margV, int gender, sol_struct* sol, par_struct* par)
    {
        double* grid_A = (gender == woman) ? par->grid_Aw : par->grid_Am;

        if (par->centered_gradient) {
            for (int iA = 1; iA < par->num_A - 1; ++iA) {
                int iA_plus = iA + 1;
                int iA_minus = iA - 1;
                double denom = 1.0 / (grid_A[iA_plus] - grid_A[iA_minus]);
                margV[iA] = V[iA_plus] * denom - V[iA_minus] * denom;
                if (iA == par->num_A - 2) margV[iA_plus] = margV[iA];
            }

            margV[0] = (margV[2] - margV[1]) / (grid_A[2] - grid_A[1]) * (grid_A[0] - grid_A[1]) + margV[1];
            int i = par->num_A - 1;
            margV[i] = (margV[i - 2] - margV[i - 1]) / (grid_A[i - 2] - grid_A[i - 1]) * (grid_A[i] - grid_A[i - 1]) + margV[i - 1];
        } else {
            for (int iA = 0; iA < par->num_A - 1; ++iA) {
                int iA_plus = iA + 1;
                double denom = 1.0 / (grid_A[iA_plus] - grid_A[iA]);
                margV[iA] = V[iA_plus] * denom - V[iA] * denom;
                if (iA == par->num_A - 2) margV[iA_plus] = margV[iA];
            }
        }
    }



    void update_optimal_discrete_solution_single_Agrid(int t, int type, int il, int iK, int gender, sol_struct* sol, par_struct* par){

        // get index
        auto idx_A = index::single(t, type, iK, 0, par);
        auto idx_d_A = index::single_d(t, type, il, iK, 0, par);

        // get variables
        double* V = &sol->Vw_single_to_single[idx_A];
        double* Vd = &sol->Vwd_single_to_single[idx_d_A];
        double* labor = &sol->lw_single_to_single[idx_A];
        if (gender == man) {
            V = &sol->Vm_single_to_single[idx_A];
            Vd = &sol->Vmd_single_to_single[idx_d_A];
            labor = &sol->lm_single_to_single[idx_A];
        }

        // Find maximum value over all labor choices
        for (int iA=0; iA < par->num_A; iA++){
            if (V[iA] < Vd[iA]) {
                V[iA] = Vd[iA];
                labor[iA] = par->grid_l[il];
            }
        }
    }


    void solve_choice_specific_single_to_single(int t, int type, int il, int iK, int gender, sol_struct *sol, par_struct *par) {

        // Terminal period: no continuation value
        if (t == (par->T - 1)) {
            solve_single_to_single_Agrid_vfi(t, type, il, iK, nullptr, gender, sol, par);
        } else {
            // next period expected value (used by VFI)
            const auto idx_next = index::single(t + 1, type, 0, 0, par);
            double* const EV_next = (gender == man) ? &sol->EVm_start_as_single[idx_next] : &sol->EVw_start_as_single[idx_next];

            // Choose EGM or VFI method
            if (par->do_egm) {
                solve_single_to_single_Agrid_egm(t, type, il, iK, gender, sol, par);
            } else {
                solve_single_to_single_Agrid_vfi(t, type, il, iK, EV_next, gender, sol, par);
            }
        }

        // Update solution with optimal discrete labor choice
        update_optimal_discrete_solution_single_Agrid(t, type, il, iK, gender, sol, par);
    }


    void solve_single_to_single(int t, sol_struct *sol,par_struct *par){
        // 1. solve choice specific
        const int ntypes   = par->num_types;
        const int nK   = par->num_K;
        const long long int total = ntypes * nK;

        #pragma omp for schedule(static)
        for (long long int idx = 0; idx < total; ++idx) {

            const auto type = par->idx_single_type[idx];
            const auto iK = par->idx_single_K[idx];

            for (int il = 0; il < par->num_l; il++) {
                solve_choice_specific_single_to_single(t, type, il, iK, woman, sol, par);
                solve_choice_specific_single_to_single(t, type, il, iK, man, sol, par);
            }
        }
    }

     double repartner_surplus(double power, index::state_couple_struct* state_couple, index::state_single_struct* state_single, int gender, par_struct* par, sol_struct* sol){
        // unpack index
        int t = state_single->t;
        int type = state_single->type;
        double A = state_single->A;
        double K = state_single->K;

        double love = state_couple->love;
        int type_w = state_couple->type_w;
        int type_m = state_couple->type_m;
        double Kw = state_couple->Kw;
        double Km = state_couple->Km;
        double A_tot = state_couple->A; 

        // gender specific
        double* V_single_to_single = sol->Vw_single_to_single;
        double* V_single_to_couple = sol->Vw_single_to_couple;
        double* grid_A_single = par->grid_Aw;
        double* grid_K_single = par->grid_Kw;
        if (gender == man){
            V_single_to_single = sol->Vm_single_to_single;
            V_single_to_couple = sol->Vm_single_to_couple;
            grid_A_single = par->grid_Am;
            grid_K_single = par->grid_Km;
        }
        
        // Get indices
        int iA_single = state_single->iA;
        int iK_single = state_single->iK;
        int iL_couple = state_couple->iL;
        int iKw_couple = state_couple->iKw;
        int iKm_couple = state_couple->iKm;
        int iA_couple = state_couple->iA;
        int iP = tools::binary_search(0, par->num_power, par->grid_power, power);

        // compute missing indices lazily
        if (iL_couple == -1) iL_couple = tools::binary_search(0, par->num_love, par->grid_love, love);
        if (iKw_couple == -1) iKw_couple = tools::binary_search(0, par->num_K, par->grid_Kw, Kw);
        if (iKm_couple == -1) iKm_couple = tools::binary_search(0, par->num_K, par->grid_Km, Km);
        if (iA_couple == -1) iA_couple = tools::binary_search(0, par->num_A, par->grid_A, A_tot);
        if (iA_single == -1) iA_single = tools::binary_search(0, par->num_A, grid_A_single, A);
        if (iK_single == -1) iK_single = tools::binary_search(0, par->num_K, grid_K_single, K);

        //interpolate V_single_to_single
        auto idx_interp_single = index::single(t, type, 0, 0, par);
        double Vsts = tools::_interp_2d(
            grid_K_single, grid_A_single, 
            par->num_K, par->num_A, 
            &V_single_to_single[idx_interp_single], 
            K, A, 
            iK_single, iA_single
        );
        // interpolate couple V_single_to_couple
        auto idx_interp_couple = index::couple(t, type_w, type_m, 0, 0, 0, 0, 0, par);
        double Vstc = tools::_interp_5d_index(
            par->grid_power, par->grid_love, par->grid_Kw, par->grid_Km, par->grid_A,
            par->num_power, par->num_love, par->num_K, par->num_K, par->num_A,
            &V_single_to_couple[idx_interp_couple], 
            power, love, Kw, Km, A_tot,
            iP, iL_couple, iKw_couple, iKm_couple, iA_couple
        );

        // surplus
        return Vstc - Vsts;
    }

    double calc_initial_bargaining_weight(int t, int type_w, int type_m, double love, double Kw, double Km, double Aw, double Am, sol_struct* sol, par_struct* par, int iL_couple=-1){
        // state structs
        index::state_couple_struct* state_couple = new index::state_couple_struct();
        index::state_single_struct* state_single_w = new index::state_single_struct();
        index::state_single_struct* state_single_m = new index::state_single_struct();

        // couple
        state_couple->t = t;
        state_couple->type_w = type_w;
        state_couple->type_m = type_m;
        state_couple->love = love;
        state_couple->Kw = Kw;
        state_couple->Km = Km;
        state_couple->A = Aw + Am;
        state_couple->iKw = tools::binary_search(0, par->num_K, par->grid_Kw, Kw);
        state_couple->iKm = tools::binary_search(0, par->num_K, par->grid_Km, Km);
        state_couple->iA = tools::binary_search(0, par->num_A, par->grid_A, Aw + Am);
        if (iL_couple == -1) iL_couple = tools::binary_search(0, par->num_love, par->grid_love, love);
        state_couple->iL = iL_couple;

        // single woman
        state_single_w->t = t;
        state_single_w->type = type_w;
        state_single_w->K = Kw;
        state_single_w->A = Aw;
        state_single_w->iA = tools::binary_search(0, par->num_A, par->grid_Aw, Aw);
        state_single_w->iK = tools::binary_search(0, par->num_K, par->grid_Kw, Kw);

        // single man
        state_single_m->t = t;
        state_single_m->type = type_m;
        state_single_m->K = Km;
        state_single_m->A = Am;
        state_single_m->iA = tools::binary_search(0, par->num_A, par->grid_Am, Am);
        state_single_m->iK = tools::binary_search(0, par->num_K, par->grid_Km, Km);

        // solver input
        bargaining::nash_solver_struct* nash_struct = new bargaining::nash_solver_struct();
        nash_struct->surplus_func = repartner_surplus;
        nash_struct->state_couple = state_couple;
        nash_struct->state_single_w = state_single_w;
        nash_struct->state_single_m = state_single_m;
        nash_struct->sol = sol;
        nash_struct->par = par;

        // solve
        double init_mu = bargaining::nash_bargain(nash_struct);

        // clean up
        delete state_couple;
        delete state_single_w;
        delete state_single_m;
        delete nash_struct;

        return init_mu;
    }
    
    
    double expected_value_cond_not_meet_partner(int t, int type, int iK, int iA, int gender, sol_struct* sol, par_struct* par){
        auto idx = index::single(t, type, iK, iA, par);
        double* V_single_to_single = (gender == man) ? sol->Vm_single_to_single : sol->Vw_single_to_single;
        return V_single_to_single[idx];
    
    }
    
    double expected_value_cond_meet_partner(int t, int type, int iK, int iA, int gender, sol_struct* sol, par_struct* par){
        // unpack
        double* V_single_to_single = sol->Vw_single_to_single;
        double* V_single_to_couple = sol->Vw_single_to_couple;
        double* prob_partner_A = par->prob_partner_A_w;
        double* prob_partner_K = par->prob_partner_Kw;
        double* prob_partner_type = par->prob_partner_type_w;
        if (gender == man){
            V_single_to_single = sol->Vm_single_to_single;
            V_single_to_couple = sol->Vm_single_to_couple;
            prob_partner_A = par->prob_partner_A_m;
            prob_partner_K = par->prob_partner_Km;
            prob_partner_type = par->prob_partner_type_m;
        }
        auto idx_single = index::single(t, type, iK, iA, par);

        // loop over potential partners conditional on meeting a partner
        double Ev_cond = 0.0;
        for (int iL_shock = 0; iL_shock < par->num_shock_love; iL_shock++) {
            const double prob_love = par->grid_weight_love[iL_shock];
            if (prob_love <= 0.0) continue;

            for (int type_p = 0; type_p < par->num_types; type_p++) { // partner's type
                auto idx_type_grid = index::index2(type, type_p, par->num_types, par->num_types);
                const double prob_type = prob_partner_type[idx_type_grid];
                if (prob_type <= 0.0) continue;

                for (int iKp = 0; iKp < par->num_K; iKp++) { // partner's capital
                    auto idx_Kgrid = index::index2(iK, iKp, par->num_K, par->num_K);
                    const double prob_K = prob_partner_K[idx_Kgrid];
                    if (prob_K <= 0.0) continue;

                    for (int iAp = 0; iAp < par->num_A; iAp++) { // partner's wealth
                        auto idx_Agrid = index::index2(iA, iAp, par->num_A, par->num_A);
                        const double prob_A = prob_partner_A[idx_Agrid];
                        if (prob_A <= 0.0) continue;
                        
                        const double prob = prob_A * prob_K * prob_type * prob_love;
                        
                        // only calculate if match has positive probability of happening
                        if (prob>0.0) {
                            int iAw = iA;
                            int iAm = iAp;
                            int iKw = iK;
                            int iKm = iKp;
                            int type_w = type;
                            int type_m = type_p;
                            if (gender == man) {
                                iAw = iAp;
                                iAm = iA;
                                iKw = iKp;
                                iKm = iK;
                                type_w = type_p;
                                type_m = type;
                            }
                            
                            // meet person with same level of wealth and human capital
                            const double Aw = par->grid_Aw[iAw];
                            const double Am = par->grid_Am[iAm];
                            const double Kw = par->grid_Kw[iKw];
                            const double Km = par->grid_Km[iKm];
                            
                            const double love = par->grid_shock_love[iL_shock] + par->mean_love;
                            double power = calc_initial_bargaining_weight(t, type_w, type_m, love, Kw, Km, Aw, Am, sol, par, -1);

                            double val;
                            if (power >= 0.0) {
                                double A_tot = Aw + Am;
                                auto idx_interp_couple = index::couple(t, type_w, type_m, 0, 0, 0, 0, 0, par); 
                                val = tools::_interp_5d(
                                    par->grid_power, par->grid_love, par->grid_Kw, par->grid_Km, par->grid_A,
                                    par->num_power, par->num_love, par->num_K, par->num_K, par->num_A,
                                    &V_single_to_couple[idx_interp_couple], 
                                    power, love, Kw, Km, A_tot
                                );
                                // note: love, Kw, Km is currently on grid 
                            } else {
                                val = V_single_to_single[idx_single];
                            }

                            Ev_cond += prob * val;
                        } // if prob>0
                    } // iAp
                } // iKp
            } // type_p
        } // iL
        return Ev_cond;
    }

    
    void calc_expected_value_single(int t, int type, int iK, int iA, int gender, double* V, double* EV, sol_struct* /*sol*/, par_struct* par)
    {

        auto idx = index::single(t, type, iK, iA, par);

        double* grid_K = (gender == woman) ? par->grid_Kw : par->grid_Km;
        double* grid_shock_K = (gender == woman) ? par->grid_shock_Kw : par->grid_shock_Km;
        double* grid_weight_K = (gender == woman) ? par->grid_weight_Kw : par->grid_weight_Km;

        double Eval = 0.0;
        double delta_K = index::single(0, 0, 1, 0, par) - index::single(0, 0, 0, 0, par);

        for (int iK_shock = 0; iK_shock < par->num_shock_K; ++iK_shock) {
            double K_shock = grid_shock_K[iK_shock] * grid_K[iK];
            K_shock = tools::max(grid_K[0], tools::min(K_shock, grid_K[par->num_K - 1]));
            double weight_K = grid_weight_K[iK_shock];
            auto idx_K = tools::binary_search(0, par->num_K, grid_K, K_shock);
                
            auto idx_interp = index::single(t, type, 0, iA, par);
            double V_now = tools::interp_1d_index_delta(grid_K, par->num_K, &V[idx_interp], K_shock, idx_K, delta_K);
            
            double weight = weight_K;
            Eval += weight * V_now;
        }

        EV[idx] = Eval;
    }


    void expected_value_start_single(int t, sol_struct* sol, par_struct* par){

        for (int sex = 0; sex < 2; sex++) {
            int gender = (sex == 0) ? woman : man;
            
            // get variables
            double* EV_start_as_single = (gender == man) ? sol->EVm_start_as_single : sol->EVw_start_as_single;
            double* EV_cond_meet_partner = (gender == man) ? sol->EVm_cond_meet_partner : sol->EVw_cond_meet_partner;
            double* EV_uncond_meet_partner = (gender == man) ? sol->EVm_uncond_meet_partner : sol->EVw_uncond_meet_partner;
            double* V_single_to_single = (gender == man) ? sol->Vm_single_to_single : sol->Vw_single_to_single;
            double* EmargV_start_as_single = (gender == man) ? sol->EmargVm_start_as_single : sol->EmargVw_start_as_single;
            
            const double p_meet = par->prob_repartner[t];
            const bool repartnering = (p_meet > 0.0);
            double EV_uncondtitional;
            
            // Total number of iterations
            const int ntypes   = par->num_types;
            const int nK   = par->num_K;
            long long int total = ntypes * nK;

            #pragma omp for schedule(static)
            for (long long int idx = 0; idx < total; ++idx) {

                const auto type = par->idx_single_type[idx];
                const auto iK = par->idx_single_K[idx];

                for (int iA = 0; iA < par->num_A; iA++) {
                    auto idx = index::single(t, type, iK, iA, par);

                    double EV_cond_not_meet = expected_value_cond_not_meet_partner(t, type, iK, iA, gender, sol, par);

                    if (repartnering) {
                        double EV_cond_meet = expected_value_cond_meet_partner(t, type, iK, iA, gender, sol, par);
                        EV_cond_meet_partner[idx] = EV_cond_meet;
                        EV_uncond_meet_partner[idx] = p_meet * EV_cond_meet + (1.0 - p_meet) * EV_cond_not_meet;
                    } else {
                        EV_uncond_meet_partner[idx] = EV_cond_not_meet;
                    }
                }
            }

            // apply quadrature weights + marginal values (type-specific slices)
            // Total number of iterations
            total = ntypes * nK;

            #pragma omp for schedule(static)
            for (long long int idx = 0; idx < total; ++idx) {

                const auto type = par->idx_single_type[idx];
                const auto iK = par->idx_single_K[idx];


                for (int iA = 0; iA < par->num_A; iA++) {
                    calc_expected_value_single(t, type, iK, iA, gender, EV_uncond_meet_partner, EV_start_as_single, sol, par);
                }

                if (par->do_egm){
                    auto idx_A = index::single(t, type, iK, 0, par);
                    calc_marginal_value_single_Agrid(&EV_start_as_single[idx_A], &EmargV_start_as_single[idx_A], gender, sol, par);
                }
            }
        }
    }

    void solve_couple_to_single(int t, sol_struct *sol, par_struct *par) {
        const double div_cost = par->div_cost;

        const int ntypes   = par->num_types;
        const int nK   = par->num_K;
        const long long int total = ntypes * nK;

        #pragma omp for schedule(static)
        for (long long int idx = 0; idx < total; ++idx) {
            
            const auto type = par->idx_single_type[idx];
            const auto iK = par->idx_single_K[idx];
            
            auto idx_A = index::single(t, type, iK, 0, par);

            double* Vw_couple_to_single = &sol->Vw_couple_to_single[idx_A];
            double* Vm_couple_to_single = &sol->Vm_couple_to_single[idx_A];
            double* Vw_single_to_single = &sol->Vw_single_to_single[idx_A];
            double* Vm_single_to_single = &sol->Vm_single_to_single[idx_A];

            for (int iA = 0; iA < par->num_A; iA++) {
                Vw_couple_to_single[iA] = Vw_single_to_single[iA] - div_cost;
                Vm_couple_to_single[iA] = Vm_single_to_single[iA] - div_cost;
            }
        }
    }

} // namespace single
