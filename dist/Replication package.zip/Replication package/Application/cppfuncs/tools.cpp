// functions related to the institutional environment.
#ifndef MAIN
#define TOOLS
#include "myheader.cpp"
#endif


namespace tools {   

double max(double a, double b){
    if (a>b){
        return a;
    } else {
        return b;
    }
}

double min(double a, double b){
    if (a<b){
        return a;
    } else {
        return b;
    }
}

double maxf(double* vec, int num){

    double max = vec[0];
    for(int i=1;i<num;i++){
        if(vec[i]>max){
            max = vec[i];
        }
    }

    return max;
}
double minf(double* vec, int num){

    double min = vec[0];
    for(int i=1;i<num;i++){
        if(vec[i]<min){
            min = vec[i];
        }
    }

    return min;
}

int binary_search(int imin, int Nx, double *x, double xi)
{
    int imid, half;

    // a. checks
    if(xi <= x[0]){
        return 0;
    } else if(xi >= x[Nx-2]) {
        return Nx-2;
    }

    // b. binary search
    Nx = Nx-imin;
    while((half = Nx/2)){
        imid = imin + half;
        imin = (x[imid] <= xi) ? imid:imin;
        Nx  -= half;
    }

    return imin;

}


int binary_search_over_descending_function(long long int idx, int Nx, double *x, double target)
{
/**
 * The function performs a binary search over a descending array to find the index of the element
 * closest to a given target value.
 * 
 * Args:
 *   idx (int): The current index to start the binary search from.
 *   Nx (int): The parameter Nx represents the size of the array x.
 *   x (double): An array of double values in descending order.
 *   target (double): The target is the value that we are searching for in the array x.
 * 
 * Returns:
 *   the index of the element in the array `x` that is closest to the target value.
 */
    int imid, half;
    // a. checks
    if(target >= x[0]){
        return 0;
    } else if(target <= x[Nx-2]) {
        return Nx-2;
    }
    // b. binary search
    Nx = Nx-(int)idx;
    while((half = Nx/2)){
        imid = (int)idx + half;
        idx = (x[imid] >= target) ? imid:idx;
        Nx  -= half;
    }
    return idx;
}

double interp_1d_index(double* grid1,int num1 ,double* value1,double xi1,int j1){
    /* 1d interpolation for one point
        
    Args:
        grid1 : 1d grid
        value : value array (2d)
        xi1 : input point
    Returns:
        yi : output
    */

    // a. left/right
    double nom_left = grid1[j1+1]-xi1;
    double nom_right = xi1-grid1[j1];

    // b. interpolation
    double denom = (grid1[j1+1]-grid1[j1]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_left;
        if (k1==1){
            nom_1 = nom_right;
        }
        nom += nom_1*value1[j1+k1];
    }

    return nom/denom;

} // interp_1d

double interp_1d(double* grid1,int num1 ,double* value1,double xi1){
    /* 1d interpolation for one point
        
    Args:
        grid1 : 1d grid
        value : value array (2d)
        xi1 : input point
    Returns:
        yi : output
    */

    // a. search 
    int j1 = binary_search(0,num1,grid1,xi1);

    return interp_1d_index(grid1,num1 ,value1,xi1,j1);

} // interp_1d


double interp_1d_index_delta(double* grid1,int num1 ,double* value1,double xi1,long long int j1, long long int delta_y=1, long long int idx_y=0, long long int delta_x=1, long long int idx_x=0){
    /* 1d interpolation for one point
        
    Args:
        grid1 : 1d grid
        value : value array (2d)
        xi1 : input point
        delta_y : delta in y direction
        idx_y : start index in y direction
        delta_x : delta in x direction
        idx_x : start index in x direction
    Returns:
        yi : output
    */
    // a. left/right
    double nom_left = grid1[idx_x+(j1+1)*delta_x]-xi1;
    double nom_right = xi1-grid1[idx_x+j1*delta_x];
    // b. interpolation
    double denom = (grid1[idx_x+(j1+1)*delta_x]-grid1[idx_x+j1*delta_x]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_left;
        if (k1==1){
            nom_1 = nom_right;
        }
        nom += nom_1*value1[idx_y + (j1+k1)*delta_y];
    }
    return nom/denom;
} // interp_1d_delta



void interp_1d_2out_index(double* grid1,int num1 ,double* value1,double* value2,double xi1 , double* out1,double* out2 ,int j1){

    // a. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    // b. interpolation
    double denom = (grid1[j1+1]-grid1[j1]);
    double nom1 = 0.0;
    double nom2 = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){
            nom_1 = nom_1_right;
        }
        nom1 += nom_1*value1[j1+k1];
        nom2 += nom_1*value2[j1+k1];
    }

    out1[0] = nom1/denom;
    out2[0] = nom2/denom;
}


void interp_1d_2out(double* grid1,int num1 ,double* value1,double* value2,double xi1 , double* out1,double* out2 ){
    /* 1d interpolation for one point
        
    Args:
        grid1 : 1d grid
        value : value array (2d)
        xi1 : input point
    Returns:
        yi : output
    */

    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);

    // b. calculate the interpolants using the index
    interp_1d_2out_index(grid1,num1,value1,value2,xi1,out1,out2 ,j1);

} // interp_1d_2out


void interp_2d_2out_index(double* grid1,double* grid2,int num2, double* value1,double* value2,double xi1,double xi2,int j1,int j2, double* out1,double* out2){
    // b. pre-calculate nom parts and denominator
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2]);

    // c. interpolation
    double nom1 = 0.0;
    double nom2 = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            nom1 += nom_1*nom_2*value1[(j1+k1)*num2 + j2+k2];
            nom2 += nom_1*nom_2*value2[(j1+k1)*num2 + j2+k2];
        }
    }
    
    out1[0] = nom1/denom;
    out2[0] = nom2/denom;

}

void interp_2d_2out(double* grid1,double* grid2,int num1, int num2,double* value1,double* value2,double xi1,double xi2, double* out1,double* out2){    
  
    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);

    interp_2d_2out_index(grid1,grid2,num2,value1,value2,xi1,xi2,j1,j2,out1,out2);
}


double _interp_2d(double* grid1,double* grid2,int num1, int num2,double* value,double xi1,double xi2,int j1, int j2){
    
    // b. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    // c. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2]);

    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            auto idx = index::index2(j1+k1,j2+k2,num1,num2);
            nom += nom_1*nom_2*value[idx]; //value[(j1+k1)*num2 + j2+k2];
        }
    }

    return nom/denom;
}
double interp_2d(double* grid1,double* grid2,int num1, int num2,double* value,double xi1,double xi2){

    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);

    return _interp_2d(grid1,grid2,num1,num2,value,xi1,xi2,j1,j2);
}

double interp_2d_int(double* grid1,double* grid2,int num1, int num2,int* value,double xi1,double xi2){
    
    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);

    // b. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    // c. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2]);

    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            auto idx = index::index2(j1+k1,j2+k2,num1,num2);
            nom += nom_1*nom_2*(double)value[idx]; //value[(j1+k1)*num2 + j2+k2];
        }
    }

    return nom/denom;
}

double _interp_3d(double* grid1,double* grid2,double* grid3,int num1, int num2, int num3,double* value,double xi1,double xi2,double xi3,int j1, int j2, int j3){

    // a. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    // b. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}            

                auto idx = index::index3(j1+k1,j2+k2,j3+k3, num1,num2, num3);   
                nom += nom_1*nom_2*nom_3*value[idx];
            }
        }
    }

    return nom/denom;
}


double interp_3d(double* grid1,double* grid2,double* grid3,int num1, int num2, int num3,double* value,double xi1,double xi2,double xi3){
    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);
    int j3 = binary_search(0,num3,grid3,xi3);

    return _interp_3d(grid1,grid2,grid3,num1,num2,num3,value,xi1,xi2,xi3,j1,j2,j3);

}


void _interp_3d_2out(double* grid1,double* grid2,double* grid3,int num1, int num2, int num3,double* value1,double* value2,double xi1,double xi2,double xi3,int j1,int j2,int j3, double* out1,double* out2){

    // a. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    // b. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3]);
    double nom1 = 0.0;
    double nom2 = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}      
                double scale = nom_1*nom_2*nom_3;      

                auto idx = index::index3(j1+k1,j2+k2,j3+k3, num1,num2, num3);   
                nom1 += scale*value1[idx];
                nom2 += scale*value2[idx];
            }
        }
    }

    out1[0] = nom1/denom;
    out2[0] = nom2/denom;
}



void interp_3d_2out(double* grid1,double* grid2,double* grid3,int num1, int num2, int num3,double* value1,double* value2,double xi1,double xi2,double xi3, double* out1,double* out2){

    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);
    int j3 = binary_search(0,num3,grid3,xi3);

    _interp_3d_2out(grid1,grid2,grid3,num1,num2,num3,value1,value2,xi1,xi2,xi3,j1,j2,j3,out1,out2);

}



double _interp_4d(double* grid1,double* grid2,double* grid3,double* grid4,int num1, int num2, int num3, int num4,double* value,double xi1,double xi2,double xi3,double xi4){
    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);
    int j3 = binary_search(0,num3,grid3,xi3);
    int j4 = binary_search(0,num4,grid4,xi4);

    // b. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    double nom_4_left = grid4[j4+1]-xi4;
    double nom_4_right = xi4-grid4[j4];

    // c. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3])*(grid4[j4+1]-grid4[j4]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}    

                for (size_t k4 = 0; k4 < 2; k4++){
                    double nom_4 = nom_4_left;
                    if (k4==1){ nom_4 = nom_4_right;}         

                    auto idx = index::index4(j1+k1,j2+k2,j3+k3,j4+k4, num1,num2, num3,num4);   
                    nom += nom_1*nom_2*nom_3*nom_4*value[idx];
                }
            }
        }
    }

    return nom/denom;
}

double _interp_4d_index(double* grid1,double* grid2,double* grid3,double* grid4,int num1, int num2, int num3, int num4,double* value,double xi1,double xi2,double xi3,double xi4, int j1, int j2, int j3, int j4){

    // b. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    double nom_4_left = grid4[j4+1]-xi4;
    double nom_4_right = xi4-grid4[j4];

    // c. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3])*(grid4[j4+1]-grid4[j4]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}    

                for (size_t k4 = 0; k4 < 2; k4++){
                    double nom_4 = nom_4_left;
                    if (k4==1){ nom_4 = nom_4_right;}         

                    auto idx = index::index4(j1+k1,j2+k2,j3+k3,j4+k4, num1,num2, num3,num4);   
                    nom += nom_1*nom_2*nom_3*nom_4*value[idx];
                }
            }
        }
    }

    return nom/denom;
}

double interp_4d(double* grid1,double* grid2,double* grid3,double* grid4,int num1, int num2, int num3, int num4,double* value,double xi1,double xi2,double xi3,double xi4){

    // check if first dimension only has one element. If so use linear_interp_2d from consav package
    // This handles that child capital might not be kept track of
    if (num1 == 1){
        return interp_3d(grid2,grid3,grid4,num2,num3,num4,value,xi2,xi3,xi4);
    } else {
        return _interp_4d(grid1,grid2,grid3,grid4,num1,num2,num3,num4,value,xi1,xi2,xi3,xi4);
    }
}

double _interp_5d_index(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,
    int num1, int num2, int num3, int num4, int num5,
    double* value,double xi1,double xi2,double xi3,double xi4,double xi5,
    int j1, int j2, int j3, int j4, int j5){

    // b. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    double nom_4_left = grid4[j4+1]-xi4;
    double nom_4_right = xi4-grid4[j4];

    double nom_5_left = grid5[j5+1]-xi5;
    double nom_5_right = xi5-grid5[j5];

    // c. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3])*(grid4[j4+1]-grid4[j4])*(grid5[j5+1]-grid5[j5]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}    

                for (size_t k4 = 0; k4 < 2; k4++){
                    double nom_4 = nom_4_left;
                    if (k4==1){ nom_4 = nom_4_right;}         

                    for (size_t k5 = 0; k5 < 2; k5++){
                        double nom_5 = nom_5_left;
                        if (k5==1){ nom_5 = nom_5_right;}

                        auto idx = index::index5(j1+k1,j2+k2,j3+k3,j4+k4,j5+k5, num1,num2, num3,num4,num5);
                        nom += nom_1*nom_2*nom_3*nom_4*nom_5*value[idx];
                    }
                }
            }
        }
    }

    return nom/denom;
}

double _interp_5d(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,
    int num1, int num2, int num3, int num4, int num5,
    double* value,double xi1,double xi2,double xi3,double xi4,double xi5 ){
    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);
    int j3 = binary_search(0,num3,grid3,xi3);
    int j4 = binary_search(0,num4,grid4,xi4);
    int j5 = binary_search(0,num5,grid5,xi5);

    // b. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    double nom_4_left = grid4[j4+1]-xi4;
    double nom_4_right = xi4-grid4[j4];

    double nom_5_left = grid5[j5+1]-xi5;
    double nom_5_right = xi5-grid5[j5];

    // c. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3])*(grid4[j4+1]-grid4[j4])*(grid5[j5+1]-grid5[j5]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}    

                for (size_t k4 = 0; k4 < 2; k4++){
                    double nom_4 = nom_4_left;
                    if (k4==1){ nom_4 = nom_4_right;}         

                    for (size_t k5 = 0; k5 < 2; k5++){
                        double nom_5 = nom_5_left;
                        if (k5==1){ nom_5 = nom_5_right;}

                        auto idx = index::index5(j1+k1,j2+k2,j3+k3,j4+k4,j5+k5, num1,num2, num3,num4,num5);
                        nom += nom_1*nom_2*nom_3*nom_4*nom_5*value[idx];
                    }
                }
            }
        }
    }

    return nom/denom;
}

double _interp_6d_index(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,double* grid6,
    int num1, int num2, int num3, int num4, int num5, int num6,
    double* value,double xi1,double xi2,double xi3,double xi4,double xi5,double xi6,
    int j1, int j2, int j3, int j4, int j5, int j6){

    // b. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    double nom_4_left = grid4[j4+1]-xi4;
    double nom_4_right = xi4-grid4[j4];

    double nom_5_left = grid5[j5+1]-xi5;
    double nom_5_right = xi5-grid5[j5];

    double nom_6_left = grid6[j6+1]-xi6;
    double nom_6_right = xi6-grid6[j6];

    // c. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3])*(grid4[j4+1]-grid4[j4])*(grid5[j5+1]-grid5[j5])*(grid6[j6+1]-grid6[j6]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}    

                for (size_t k4 = 0; k4 < 2; k4++){
                    double nom_4 = nom_4_left;
                    if (k4==1){ nom_4 = nom_4_right;}         

                    for (size_t k5 = 0; k5 < 2; k5++){
                        double nom_5 = nom_5_left;
                        if (k5==1){ nom_5 = nom_5_right;}

                        for (size_t k6 = 0; k6 < 2; k6++){
                            double nom_6 = nom_6_left;
                            if (k6==1){ nom_6 = nom_6_right;}

                            auto idx = index::index6(j1+k1,j2+k2,j3+k3,j4+k4,j5+k5,j6+k6, num1,num2, num3,num4,num5,num6);
                            nom += nom_1*nom_2*nom_3*nom_4*nom_5*nom_6*value[idx];
                        }
                    }
                }
            }
        }
    }

    return nom/denom;
}

double _interp_6d(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,double* grid6,
    int num1, int num2, int num3, int num4, int num5, int num6,
    double* value,double xi1,double xi2,double xi3,double xi4,double xi5,double xi6){

    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);
    int j3 = binary_search(0,num3,grid3,xi3);
    int j4 = binary_search(0,num4,grid4,xi4);
    int j5 = binary_search(0,num5,grid5,xi5);
    int j6 = binary_search(0,num6,grid6,xi6);

    return _interp_6d_index(grid1,grid2,grid3,grid4,grid5,grid6,num1,num2,num3,num4,num5,num6,value,xi1,xi2,xi3,xi4,xi5,xi6,j1,j2,j3,j4,j5,j6);

}

double _interp_7d_index(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,double* grid6,double* grid7,
    int num1, int num2, int num3, int num4, int num5, int num6, int num7,
    double* value,double xi1,double xi2,double xi3,double xi4,double xi5,double xi6,double xi7,
    int j1, int j2, int j3, int j4, int j5, int j6, int j7){

    // b. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    double nom_4_left = grid4[j4+1]-xi4;
    double nom_4_right = xi4-grid4[j4];

    double nom_5_left = grid5[j5+1]-xi5;
    double nom_5_right = xi5-grid5[j5];

    double nom_6_left = grid6[j6+1]-xi6;
    double nom_6_right = xi6-grid6[j6];

    double nom_7_left = grid7[j7+1]-xi7;
    double nom_7_right = xi7-grid7[j7];

    // c. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3])*(grid4[j4+1]-grid4[j4])*(grid5[j5+1]-grid5[j5])*(grid6[j6+1]-grid6[j6])*(grid7[j7+1]-grid7[j7]);
    double nom = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}    

                for (size_t k4 = 0; k4 < 2; k4++){
                    double nom_4 = nom_4_left;
                    if (k4==1){ nom_4 = nom_4_right;}         

                    for (size_t k5 = 0; k5 < 2; k5++){
                        double nom_5 = nom_5_left;
                        if (k5==1){ nom_5 = nom_5_right;}

                        for (size_t k6 = 0; k6 < 2; k6++){
                            double nom_6 = nom_6_left;
                            if (k6==1){ nom_6 = nom_6_right;}

                            for (size_t k7 = 0; k7 < 2; k7++){
                                double nom_7 = nom_7_left;
                                if (k7==1){ nom_7 = nom_7_right;}

                                auto idx = index::index7(j1+k1,j2+k2,j3+k3,j4+k4,j5+k5,j6+k6,j7+k7, num1,num2, num3,num4,num5,num6,num7);
                                nom += nom_1*nom_2*nom_3*nom_4*nom_5*nom_6*nom_7*value[idx];
                            }
                        }
                    }
                }
            }
        }
    }

    return nom/denom;
}

double _interp_7d(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,double* grid6,double* grid7,
    int num1, int num2, int num3, int num4, int num5, int num6, int num7,
    double* value,double xi1,double xi2,double xi3,double xi4,double xi5,double xi6,double xi7){

    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);
    int j3 = binary_search(0,num3,grid3,xi3);
    int j4 = binary_search(0,num4,grid4,xi4);
    int j5 = binary_search(0,num5,grid5,xi5);
    int j6 = binary_search(0,num6,grid6,xi6);
    int j7 = binary_search(0,num7,grid7,xi7);

    return _interp_7d_index(grid1,grid2,grid3,grid4,grid5,grid6,grid7,num1,num2,num3,num4,num5,num6,num7,value,
        xi1,xi2,xi3,xi4,xi5,xi6,xi7,j1,j2,j3,j4,j5,j6,j7);
}

void _interp_5d_2out_index(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,
    int num1, int num2, int num3, int num4, int num5,
    double* value1,double* value2,
    double xi1,double xi2,double xi3,double xi4,double xi5,
    int j1, int j2, int j3, int j4, int j5,
    double* out1,double* out2){

    // a. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    double nom_4_left = grid4[j4+1]-xi4;
    double nom_4_right = xi4-grid4[j4];

    double nom_5_left = grid5[j5+1]-xi5;
    double nom_5_right = xi5-grid5[j5];

    // b. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3])*(grid4[j4+1]-grid4[j4])*(grid5[j5+1]-grid5[j5]);
    double nom1 = 0.0;
    double nom2 = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}    

                for (size_t k4 = 0; k4 < 2; k4++){
                    double nom_4 = nom_4_left;
                    if (k4==1){ nom_4 = nom_4_right;}         

                    for (size_t k5 = 0; k5 < 2; k5++){
                        double nom_5 = nom_5_left;
                        if (k5==1){ nom_5 = nom_5_right;}

                        auto idx = index::index5(j1+k1,j2+k2,j3+k3,j4+k4,j5+k5, num1,num2, num3,num4,num5);
                        nom1 += nom_1*nom_2*nom_3*nom_4*nom_5*value1[idx];
                        nom2 += nom_1*nom_2*nom_3*nom_4*nom_5*value2[idx];
                    }
                }
            }
        }
    }

    out1[0] = nom1/denom;
    out2[0] = nom2/denom;
}

void interp_5d_2out(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,
    int num1, int num2, int num3, int num4, int num5,
    double* value1,double* value2,
    double xi1,double xi2,double xi3,double xi4,double xi5,
    double* out1,double* out2){

    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);
    int j3 = binary_search(0,num3,grid3,xi3);
    int j4 = binary_search(0,num4,grid4,xi4);
    int j5 = binary_search(0,num5,grid5,xi5);

    _interp_5d_2out_index(grid1,grid2,grid3,grid4,grid5,num1,num2,num3,num4,num5,
        value1,value2,xi1,xi2,xi3,xi4,xi5,j1,j2,j3,j4,j5,out1,out2);
}


void _interp_7d_2out_index(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,double* grid6,double* grid7,
    int num1, int num2, int num3, int num4, int num5, int num6, int num7,
    double* value1,double* value2,
    double xi1,double xi2,double xi3,double xi4,double xi5,double xi6,double xi7,
    int j1, int j2, int j3, int j4, int j5, int j6, int j7,
    double* out1,double* out2){

    // a. left/right
    double nom_1_left = grid1[j1+1]-xi1;
    double nom_1_right = xi1-grid1[j1];

    double nom_2_left = grid2[j2+1]-xi2;
    double nom_2_right = xi2-grid2[j2];

    double nom_3_left = grid3[j3+1]-xi3;
    double nom_3_right = xi3-grid3[j3];

    double nom_4_left = grid4[j4+1]-xi4;
    double nom_4_right = xi4-grid4[j4];

    double nom_5_left = grid5[j5+1]-xi5;
    double nom_5_right = xi5-grid5[j5];

    double nom_6_left = grid6[j6+1]-xi6;
    double nom_6_right = xi6-grid6[j6];

    double nom_7_left = grid7[j7+1]-xi7;
    double nom_7_right = xi7-grid7[j7];

    // b. interpolation
    double denom = (grid1[j1+1]-grid1[j1])*(grid2[j2+1]-grid2[j2])*(grid3[j3+1]-grid3[j3])*(grid4[j4+1]-grid4[j4])*(grid5[j5+1]-grid5[j5])*(grid6[j6+1]-grid6[j6])*(grid7[j7+1]-grid7[j7]);
    double nom1 = 0.0;
    double nom2 = 0.0;
    for (size_t k1 = 0; k1 < 2; k1++){
        double nom_1 = nom_1_left;
        if (k1==1){ nom_1 = nom_1_right;}

        for (size_t k2 = 0; k2 < 2; k2++){
            double nom_2 = nom_2_left;
            if (k2==1){ nom_2 = nom_2_right;}

            for (size_t k3 = 0; k3 < 2; k3++){
                double nom_3 = nom_3_left;
                if (k3==1){ nom_3 = nom_3_right;}    

                for (size_t k4 = 0; k4 < 2; k4++){
                    double nom_4 = nom_4_left;
                    if (k4==1){ nom_4 = nom_4_right;}         

                    for (size_t k5 = 0; k5 < 2; k5++){
                        double nom_5 = nom_5_left;
                        if (k5==1){ nom_5 = nom_5_right;}

                        for (size_t k6 = 0; k6 < 2; k6++){
                            double nom_6 = nom_6_left;
                            if (k6==1){ nom_6 = nom_6_right;}

                            for (size_t k7 = 0; k7 < 2; k7++){
                                double nom_7 = nom_7_left;
                                if (k7==1){ nom_7 = nom_7_right;}

                                auto idx = index::index7(j1+k1,j2+k2,j3+k3,j4+k4,j5+k5,j6+k6,j7+k7, num1,num2, num3,num4,num5,num6,num7);
                                nom1 += nom_1*nom_2*nom_3*nom_4*nom_5*nom_6*nom_7*value1[idx];
                                nom2 += nom_1*nom_2*nom_3*nom_4*nom_5*nom_6*nom_7*value2[idx];
                            }
                        }
                    }
                }
            }
        }
    }

    out1[0] = nom1/denom;
    out2[0] = nom2/denom;
}

void interp_7d_2out(double* grid1,double* grid2,double* grid3,double* grid4,double* grid5,double* grid6,double* grid7,
    int num1, int num2, int num3, int num4, int num5, int num6, int num7,
    double* value1,double* value2,
    double xi1,double xi2,double xi3,double xi4,double xi5,double xi6,double xi7,
    double* out1,double* out2){

    // a. search in each dimension
    int j1 = binary_search(0,num1,grid1,xi1);
    int j2 = binary_search(0,num2,grid2,xi2);
    int j3 = binary_search(0,num3,grid3,xi3);
    int j4 = binary_search(0,num4,grid4,xi4);
    int j5 = binary_search(0,num5,grid5,xi5);
    int j6 = binary_search(0,num6,grid6,xi6);
    int j7 = binary_search(0,num7,grid7,xi7);

    _interp_7d_2out_index(grid1,grid2,grid3,grid4,grid5,grid6,grid7,num1,num2,num3,num4,num5,num6,num7,
        value1,value2,xi1,xi2,xi3,xi4,xi5,xi6,xi7,j1,j2,j3,j4,j5,j6,j7,out1,out2);
}

} // tools