import stat
import ctypes
import os
import warnings
import numpy as np
import numba as nb
from scipy.stats import norm, multivariate_normal
import scipy.optimize as optimize
from scipy.optimize import minimize
from scipy.optimize import brentq
from collections import OrderedDict

from EconModel import EconModelClass
from consav.grids import nonlinspace
from consav import linear_interp, linear_interp_1d
from consav import quadrature
import scipy.stats as stats

import time

# set gender indication as globals
woman = 1
man = 2

class HouseholdModelClass(EconModelClass):
    
    def settings(self):
        """ fundamental settings """

        # a. namespaces
        self.namespaces = []
        
        # b. other attributes
        self.other_attrs = []
        
        # c. savefolder
        self.savefolder = 'saved'
        
        # d. cpp
        self.cpp_filename = 'cppfuncs/solve.cpp'
        self.cpp_options = {'compiler':'vs'}
        
    def setup(self):
        par = self.par

        # -------- core / accounting --------
        par.R = 1.03 # Interest rate (Voena (2015) - Jakobsen, Jørgensen and Low (2024) - 1.015 in Attanasio, Low, and Sánchez-Marcos (2008))
        par.beta = 0.98  # Discount factor (Bronson, Haanwinckel, and Mazzocco (2025) / Attanasio, Low, and Sánchez-Marcos (2008))

        par.div_A_share = 0.5  # divorce share of wealth to wife (Bronson (2019) - Voena (2015) estimates something slightly different)
        par.div_cost = 0.0

        par.available_hours = 7*16.0 * 52 / 1000 # 1 = thousends of awake hours a year
        par.full_time_hours = 40.0 * 52 / 1000 # ~0.36 (40 hours per week - out of 16 hours per day, 7 days per week)
        par.part_time_hours = 20.0 * 52 / 1000 # ~0.18 (20 hours per week - out of 16 hours per day, 7 days per week)
        
        par.money_metric = 1000.0 # 1 = thousands of USD

        # -------- preferences (baseline + multipliers) --------
        par.rho = 1.5 # (Bronson, Haanwinckel, and Mazzocco (2025) / Attanasio, Low, and Sánchez-Marcos (2008))
        par.rho_mult = 1.0

        par.phi = 3.0
        par.phi_mult = 1.14

        par.eta = 2.25
        par.eta_mult = 1.25

        par.lambda_ = 11.55
        par.lambda_mult = 1.0

        # -------- home production --------
        par.alpha = 1.03
        par.zeta = 0.40 # (Bronson, Haanwinckel, and Mazzocco (2025))
        par.omega = 0.38 # (Bronson, Haanwinckel, and Mazzocco (2025))
        par.pi = 0.6

        # -------- income / wages (baseline + multipliers) --------
        par.mu = 0.8
        par.sigma_mu = 0.54
        par.gamma = 0.13
        par.gamma2 = 0.00

        par.mu_mult = 1.08
        par.sigma_mu_mult = 1.0
        par.gamma_mult = 1.95
        par.gamma2_mult = 1.0

        # -------- human capital process --------
        par.phi_k = 1.0 # (Jakobsen, Jørgensen and Low (2024))
        par.delta = 0.1 # (Jakobsen, Jørgensen and Low (2024))
        
        # -------- model horizon / state space sizes --------
        par.T = 40

        # wealth
        par.num_A = 30
        par.max_A = 3000.0

        # human capital
        par.num_K = 10
        par.max_K = 10.0 * par.available_hours
        par.sigma_K = 0.1 # (Jakobsen, Jørgensen and Low (2024))
        par.sigma_K_mult = 1.0
        par.num_shock_K = 5

        # bargaining power
        par.num_power = 11

        # love / match quality
        par.num_love = 11
        par.max_love = 50.0
        par.sigma_love = 7.0
        par.mean_love = 0.0 # normalization
        par.num_shock_love = 5  # cannot be 1 due to interpolation

        # types
        par.num_types = 4
        par.type_corr = 0.45 # (Bronson, Haanwinckel, and Mazzocco (2025))
        
        # EGM
        par.num_A_pd = 30
        par.max_A_pd = 3000.0
        
        # precomputation of intratemporal solution (for iEGM)
        par.num_marg_u = 200

        # -------- (re-)partnering --------
        par.p_meet = 0.0
        par.prob_partner_Kw = np.array([[np.nan]])
        par.prob_partner_Km = np.array([[np.nan]])
        par.prob_partner_A_w = np.array([[np.nan]])
        par.prob_partner_A_m = np.array([[np.nan]])
        par.prob_partner_type_w = np.array([[np.nan]])
        par.prob_partner_type_m = np.array([[np.nan]])


        # -------- precomputation controls --------
        par.interp_inverse = False
        par.precompute_intratemporal = True

        # intratemporal precomputation
        par.num_Ctot = 200
        par.max_Ctot = 3000.0

        # EGM
        par.do_egm = False

        # -------- simulation --------
        par.seed = 9210
        par.simT = 40
        par.simN = 100_000
        par.init_couple_share = 0.80

        # -------- misc --------
        par.threads = 8
        par.do_multistart = True
        par.init_bargaining_in_sim = True
        par.interp_method = "linear"
        par.centered_gradient = True
        par.bargaining = "limited"

        # -------- accuracy measures --------
        par.num_acc = 12 # length of all accuracy grids
        par.trunc_min = 0.2 # accuracy grids span the fractional range [trunc_min, trunc_max] of each state grid
        par.trunc_max = 0.8

    def setup_gender_parameters(self):
        par = self.par
        
        # set
        par.mu_w = par.mu
        par.mu_m = par.mu * par.mu_mult
        
        par.gamma_w = par.gamma
        par.gamma_m = par.gamma * par.gamma_mult
        
        par.gamma2_w = par.gamma2
        par.gamma2_m = par.gamma2 * par.gamma2_mult

        par.rho_w = par.rho
        par.rho_m = par.rho * par.rho_mult

        par.phi_w = par.phi
        par.phi_m = par.phi * par.phi_mult

        par.eta_w = par.eta
        par.eta_m = par.eta * par.eta_mult

        # keep python keyword safe name `lambda_` as baseline, derive `lambda_w`/`lambda_m`
        par.lambda_w = par.lambda_
        par.lambda_m = par.lambda_ * par.lambda_mult

        par.sigma_Kw = par.sigma_K
        par.sigma_Km = par.sigma_K * par.sigma_K_mult
        
    @staticmethod
    def fast_unravel_indices(shape, dtype=np.int32):
        """Helper function to unravel indices for a given shape (for unindexing grids).
        This is a faster implementation of np.unravel_index for large arrays, as it avoids creating large intermediate arrays.
        INPUT:
        - shape: tuple, the shape of the array to unravel indices for
        - dtype: data type of the output indices (default: np.int32)
        
        OUTPUT:
        - tuple of arrays, where each array contains the indices for that dimension
        """
        size = np.prod(shape)
        idx = np.arange(size, dtype=dtype)

        out = []
        for dim in reversed(shape):
            out.append(idx % dim)
            idx //= dim

        return tuple(np.ascontiguousarray(x) for x in reversed(out))

    @staticmethod
    def assortative_matrix(num, corr):
        """
        Construct assortative matching matrix P(partner_state | own_state)

        Parameters
        ----------
        num : int
            Number of discrete states
        corr : float
            Correlation between latent partner states

        Returns
        -------
        numpy.ndarray
            (num x num) matrix where rows sum to 1
        """

        # assume types are distributed as standard normal and cut into equal-probability bins
        cuts = norm.ppf(np.linspace(0, 1, num=num + 1))
        # set extreme values for the first and last cut instead of inf values
        cuts[0] = -10 
        cuts[-1] = 10

        cov = [[1, corr], [corr, 1]]
        joint = np.zeros((num, num))

        for i in range(num):
            for j in range(num):
                lower = [cuts[i], cuts[j]]
                upper = [cuts[i+1], cuts[j+1]]

                p = (
                    multivariate_normal.cdf(upper, cov=cov, allow_singular=True)
                    - multivariate_normal.cdf([lower[0], upper[1]], cov=cov, allow_singular=True)
                    - multivariate_normal.cdf([upper[0], lower[1]], cov=cov, allow_singular=True)
                    + multivariate_normal.cdf(lower, cov=cov, allow_singular=True)
                )

                joint[i, j] = p

        # convert to conditional probabilities
        return joint / joint.sum(axis=1, keepdims=True)


    def setup_grids(self):
        par = self.par

        # ---------- 0) time ----------
        par.grid_t = np.arange(par.T)

        # ---------- 1) types ----------
        par.grid_type = np.arange(par.num_types, dtype=np.float64)
        par.grid_mu_w, par.type_w_share = quadrature.normal_gauss_hermite(par.sigma_mu, par.num_types, mu=par.mu)
        par.grid_mu_m, par.type_m_share = quadrature.normal_gauss_hermite(
            par.sigma_mu * par.sigma_mu_mult, par.num_types, mu=par.mu * par.mu_mult
        )

        # ---------- 2) discrete choices ----------
        par.grid_l = np.array([0.0, par.part_time_hours, par.full_time_hours]) / par.available_hours # discrete labor choices as share of available hours
        par.num_l = len(par.grid_l) 

        # ---------- 3) state grids ----------
        # 3.1 assets
        par.grid_A = nonlinspace(0.0, par.max_A, par.num_A, 1.1)
        par.grid_Aw = par.div_A_share * par.grid_A
        par.grid_Am = (1.0 - par.div_A_share) * par.grid_A

        # 3.2 human capital
        par.grid_Kw = nonlinspace(0.0, par.max_K, par.num_K, 1.0)
        par.grid_Km = nonlinspace(0.0, par.max_K, par.num_K, 1.0)

        # 3.3 bargaining power (more mass in tails)
        odd_num = np.mod(par.num_power, 2)
        first_part = nonlinspace(1e-6, 0.5, (par.num_power + odd_num) // 2, 1.3)
        last_part = np.flip(1.0 - nonlinspace(1e-6, 0.5, (par.num_power - odd_num) // 2 + 1, 1.3))[1:]
        par.grid_power = np.append(first_part, last_part)
        par.grid_power_flip = np.flip(par.grid_power)

        # 3.4 love
        par.grid_love = np.linspace(-par.max_love, par.max_love, par.num_love) if par.num_love > 1 else np.array([par.mean_love])

        # ---------- 4) shocks ----------
        par.grid_shock_Kw, par.grid_weight_Kw = quadrature.log_normal_gauss_hermite(par.sigma_Kw, par.num_shock_K)
        par.grid_shock_Km, par.grid_weight_Km = quadrature.log_normal_gauss_hermite(par.sigma_Km, par.num_shock_K)

        if par.sigma_love <= 1.0e-6:
            par.num_shock_love = 1
            par.grid_shock_love, par.grid_weight_love = np.array([0.0]), np.array([1.0])
        else:
            par.grid_shock_love, par.grid_weight_love = quadrature.normal_gauss_hermite(par.sigma_love, par.num_shock_love)

        # ---------- 5) EGM / iEGM grids ----------
        # post-decision assets
        par.grid_A_pd = nonlinspace(0.0, par.max_A_pd, par.num_A_pd, 1.1)
        par.grid_Aw_pd = par.div_A_share * par.grid_A_pd
        par.grid_Am_pd = (1.0 - par.div_A_share) * par.grid_A_pd

        # total consumption grid + marginal utility grid
        par.grid_Ctot = nonlinspace(1.0e-6, par.max_Ctot, par.num_Ctot, 1.1)
        par.grid_C_for_marg_u = nonlinspace(1.0e-5, par.max_Ctot, par.num_marg_u, 1.1)

        par.grid_inv_marg_u = np.flip(par.grid_C_for_marg_u)
        if par.interp_inverse:
            par.grid_inv_marg_u = 1.0/par.grid_inv_marg_u        
        
        # TJ: numerical
        par.grid_Wpre = nonlinspace(1.0e-6, 0.8, par.num_Ctot, 1.1)
        
        
        # ---------- 6) repartnering ----------
        
        # re-partering probabilities
        par.prob_repartner = par.p_meet*np.ones(par.T) # likelihood of meeting a partner
        
        def _use_eye_if_nan(arr, n):
            return np.eye(n) if np.isnan(arr[0, 0]) else arr
            
        par.prob_partner_Kw = _use_eye_if_nan(par.prob_partner_Kw, par.num_K)
        par.prob_partner_Km = _use_eye_if_nan(par.prob_partner_Km, par.num_K)
        par.prob_partner_A_w = _use_eye_if_nan(par.prob_partner_A_w, par.num_A)
        par.prob_partner_A_m = _use_eye_if_nan(par.prob_partner_A_m, par.num_A)
        if np.isnan(par.prob_partner_type_w[0, 0]):
            par.prob_partner_type_w = self.assortative_matrix(par.num_types, corr=par.type_corr)
        if np.isnan(par.prob_partner_type_m[0, 0]):
            par.prob_partner_type_m = self.assortative_matrix(par.num_types, corr=par.type_corr)
     
        par.cdf_partner_Kw = np.cumsum(par.prob_partner_Kw,axis=1) # cumulative distribution to be used in simulation
        par.cdf_partner_Km = np.cumsum(par.prob_partner_Km,axis=1)
        par.cdf_partner_Aw = np.cumsum(par.prob_partner_A_w,axis=1) # cumulative distribution to be used in simulation
        par.cdf_partner_Am = np.cumsum(par.prob_partner_A_m,axis=1)
        par.cdf_partner_type_w = np.cumsum(par.prob_partner_type_w,axis=1)
        par.cdf_partner_type_m = np.cumsum(par.prob_partner_type_m,axis=1)
        
        # Norm distributed initial love - note: Probability mass between points (approximation of continuous distribution)
        if par.sigma_love <= 1.0e-6:
            love_cdf = np.where(par.grid_love >= 0.0,1.0,0.0)
        else:
            love_cdf = stats.norm.cdf(par.grid_love,par.mean_love,par.sigma_love)
        par.prob_partner_love = np.append(np.diff(love_cdf, 1), 0.0)

        # ---------- 7) accuracy grids ----------
        def _acc_grid(grid):
            return grid[0] + (grid[-1] - grid[0]) * np.linspace(par.trunc_min, par.trunc_max, par.num_acc)

        par.grid_power_acc = _acc_grid(par.grid_power)
        par.grid_love_acc = _acc_grid(par.grid_love)
        par.grid_Kw_acc = _acc_grid(par.grid_Kw)
        par.grid_Km_acc = _acc_grid(par.grid_Km)
        par.grid_A_acc = _acc_grid(par.grid_A)


    def allocate(self):
        """Allocate model storage (memory) and initialize all values."""
        # derive gender-specific parameters + grids (needed for sizes)
        self.setup_gender_parameters()
        self.setup_grids()

        self.setup_sol(allocate=True)
        self.setup_sim(allocate=True)
        self.draw_shocks_and_initial_states()
            
    @staticmethod
    def _alloc(obj, name, shape, dtype=np.float64, value=np.nan, allocate=True):
        if allocate:
            setattr(obj, name, np.empty(shape, dtype=dtype))
        # can't use nan if dtype is int or bool, so set to other value in that case
        if np.isnan(value):
            if np.issubdtype(dtype, np.unsignedinteger):
                value = 9999
            elif np.issubdtype(dtype, np.integer):
                value = -9999
            elif np.issubdtype(dtype, np.bool_):
                value = False
        getattr(obj, name)[...] = value

    def setup_sol(self, allocate=True):
        """
        Allocate solution storage (memory) and initialize all values.
        
        args:
            - allocate: bool, if True, allocate memory for all arrays.
        """
        par = self.par
        sol = self.sol
        
        def alloc(name, shape, dtype=np.float64, value=np.nan):
            self._alloc(sol, name, shape, dtype=dtype, value=value, allocate=allocate)

        # singles
        shape_single = (par.T, par.num_types, par.num_K, par.num_A)
        shape_single_d = (par.T, par.num_types, par.num_l, par.num_K, par.num_A)
        shape_single_egm = (par.T, par.num_types, par.num_l, par.num_K, par.num_A_pd)

        # couples
        shape_couple = (par.T, par.num_types, par.num_types, par.num_power, par.num_love, par.num_K, par.num_K, par.num_A)
        shape_couple_d = (par.T, par.num_types, par.num_types, par.num_l, par.num_l, par.num_power, par.num_love, par.num_K, par.num_K, par.num_A)
        shape_couple_egm = (par.T, par.num_types, par.num_types, par.num_l, par.num_l, par.num_power,par.num_love, par.num_K, par.num_K,par.num_A_pd)
 
        # precomputations
        shape_pre_single = (par.num_l, par.num_Ctot)
        shape_pre_couple = (par.num_l, par.num_l, par.num_power, par.num_Ctot)
        shape_iegm_single = (par.num_l, par.num_marg_u)
        shape_iegm_couple = (par.num_l, par.num_l, par.num_power, par.num_marg_u)
        

        # --- single to single (discrete l choices) ---
        for name in (
            "Vwd_single_to_single", "Vmd_single_to_single",
        ):
            alloc(name, shape_single_d, value=-np.inf)
                
        for name in (
            "Cwd_tot_single_to_single", "Cmd_tot_single_to_single",
            "Cwd_priv_single_to_single", "Cmd_priv_single_to_single",
            "Cwd_inter_single_to_single", "Cmd_inter_single_to_single",
            "Qwd_single_to_single", "Qmd_single_to_single",
            "lwd_single_to_single", "lmd_single_to_single",
            "hwd_single_to_single", "hmd_single_to_single",
        ):
            alloc(name, shape_single_d, value=np.nan)

        # --- single to single (EGM post-decision) ---
        for name in (
            "EmargUwd_single_to_single_pd", "Cwd_tot_single_to_single_pd",
            "Mwd_single_to_single_pd", "Vwd_single_to_single_pd",
            "EmargUmd_single_to_single_pd", "Cmd_tot_single_to_single_pd",
            "Mmd_single_to_single_pd", "Vmd_single_to_single_pd",
        ):
            alloc(name, shape_single_egm, value=0.0)

        # --- couple to single ---
        for name in (
            "Vw_couple_to_single", "Vm_couple_to_single",
        ):
            alloc(name, shape_single, value=np.nan)

        # --- start as single ---
        for name in (
            "EVw_start_as_single", "EVm_start_as_single",
        ):
            alloc(name, shape_single, value=-np.inf)
        
        for name in (
            "EmargVw_start_as_single", "EmargVm_start_as_single",
            "EVw_cond_meet_partner", "EVm_cond_meet_partner",
            "EVw_uncond_meet_partner", "EVm_uncond_meet_partner",
        ):
            alloc(name, shape_single, value=np.nan)
            
        # --- optimal discrete choices single ---
        for name in (
            "Vw_single_to_single", "Vm_single_to_single",
        ):
            alloc(name, shape_single, value=-np.inf)
        
        for name in (
            "Cw_tot_single_to_single", "Cm_tot_single_to_single",
            "lw_single_to_single", "lm_single_to_single",
        ):
            alloc(name, shape_single, value=np.nan)

        # --- couple to couple ---
        for name in (
            "Vd_couple_to_couple",
        ):
            alloc(name, shape_couple_d, value=-np.inf)
        for name in (
            "Vwd_couple_to_couple", "Vmd_couple_to_couple", 
            "Cwd_priv_couple_to_couple", "Cmd_priv_couple_to_couple",
            "Cd_inter_couple_to_couple", "Qd_couple_to_couple",
            "lwd_couple_to_couple", "lmd_couple_to_couple",
            "hwd_couple_to_couple", "hmd_couple_to_couple",
            "Cd_tot_couple_to_couple",
        ):
            alloc(name, shape_couple_d, value=np.nan)

        # state-level power objects (must be shape_couple)
        alloc("power_idx", shape_couple, dtype=np.int32, value=0)
        alloc("power", shape_couple, value=np.nan)

        # --- couple to couple (EGM post-decision) ---
        for name in (
            "EmargUd_pd", "Cd_tot_pd", "Md_pd", "Vd_couple_to_couple_pd"
        ):
            alloc(name, shape_couple_egm, value=0.0)

        # --- single to couple ---
        for name in (
            "V_single_to_couple",
        ):
            alloc(name, shape_couple, value=-np.inf)
        
        for name in (
            "Vw_single_to_couple", "Vm_single_to_couple",
        ):
            alloc(name, shape_couple, value=np.nan)
            
        # --- start as couple ---
        for name in (
            "Vw_start_as_couple", "Vm_start_as_couple", "margV_start_as_couple",
            "EVw_start_as_couple", "EVm_start_as_couple", "EmargV_start_as_couple",
        ):
            alloc(name, shape_couple, value=np.nan)
            
        # --- optimal discrete choices couple ---
        for name in (
            "V_couple_to_couple", 
        ):
            alloc(name, shape_couple, value=-np.inf)
            
        for name in (
            "Vw_couple_to_couple", "Vm_couple_to_couple",
            "C_tot_couple_to_couple", 
            "lw_couple_to_couple", "lm_couple_to_couple",
        ):
            alloc(name, shape_couple, value=np.nan)

        # --- precomputed intratemporal solution ---
        for name in (
            "pre_Cwd_priv_single", "pre_Cmd_priv_single",
            "pre_Cwd_inter_single", "pre_Cmd_inter_single",
            "pre_Qwd_single", "pre_Qmd_single",
            "pre_hwd_single", "pre_hmd_single",
        ):
            alloc(name, shape_pre_single, value=np.nan)
        
        for name in (
            "grid_marg_u_single_w", "grid_marg_u_single_m",
            "grid_marg_u_single_w_for_inv", "grid_marg_u_single_m_for_inv",
        ):
            alloc(name, shape_iegm_single, value=np.nan)

        for name in (
            "pre_Cwd_priv_couple", "pre_Cmd_priv_couple",
            "pre_Cd_inter_couple", "pre_Qd_couple",
            "pre_hwd_couple", "pre_hmd_couple",
        ):
            alloc(name, shape_pre_couple, value=np.nan)
            
        for name in (
            "grid_marg_u_couple", "grid_marg_u_couple_for_inv",
        ):
            alloc(name, shape_iegm_couple, value=np.nan)
            
        # timing
        for name in (
            "solution_time",
        ):
            alloc(name, (1,), value=np.nan)
            
        # --- flat index arrays (unindexing for grids) ---
        shape_couple_bargaining = (par.num_types, par.num_types, par.num_love, par.num_K, par.num_K)

        par.idx_single_type, par.idx_single_K = self.fast_unravel_indices(shape_single[1:-1], dtype=np.int64)
        par.idx_couple_type_w, par.idx_couple_type_m, par.idx_couple_power, par.idx_couple_love, par.idx_couple_Kw, par.idx_couple_Km = self.fast_unravel_indices(shape_couple[1:-1], dtype=np.int64)
        par.idx_couple_barg_type_w, par.idx_couple_barg_type_m, par.idx_couple_barg_love, par.idx_couple_barg_Kw, par.idx_couple_barg_Km = self.fast_unravel_indices(shape_couple_bargaining, dtype=np.int64)
        par.idx_pre_couple_lw, par.idx_pre_couple_lm, par.idx_pre_couple_power, = self.fast_unravel_indices(shape_pre_couple[:-1], dtype=np.int64)
    


    def setup_sim(self, allocate=True):
        """
        Allocate simulation storage (memory) and initialize all values.

        args:
            - allocate: bool, if True, allocate memory for all arrays.
        """
        par = self.par
        sim = self.sim

        def alloc(name, shape, dtype=np.float64, value=np.nan):
            self._alloc(sim, name, shape, dtype=dtype, value=value, allocate=allocate)

        # simulation
        shape_sim = (par.simN, par.simT)

        # --- simulation output variables ---
        for name in (
            "lw", "lm", "Cw_priv", "Cm_priv", "hw", "hm",
            "Cw_inter", "Cm_inter", "Qw", "Qm",
            "Cw_tot", "Cm_tot", "C_tot",
            "Kw", "Km", "A", "Aw", "Am",
            "couple", "power", "love",
            "wage_inc_w", "wage_inc_m", "after_tax_inc_w", "after_tax_inc_m",
            "leisure_w", "leisure_m",
            "util_w", "util_m",
        ):
            alloc(name, shape_sim, value=np.nan)

        alloc("divorces", shape_sim, value=0.0)
        alloc("mean_lifetime_util", (1,), value=np.nan)
        alloc("C_ineq_90_10", (1, par.simT), value=np.nan)

        # --- shock draw arrays ---
        if allocate:
            for name in (
                "draw_shock_Kw", "draw_shock_Km", "draw_love", "draw_meet",
                "draw_uniform_partner_Kw", "draw_uniform_partner_Km",
                "draw_uniform_partner_Aw", "draw_uniform_partner_Am",
                "draw_uniform_partner_type_w", "draw_uniform_partner_type_m",
                "draw_repartner_love",
            ):
                alloc(name, shape_sim, value=np.nan)

        # --- initial state arrays ---
        if allocate:
            for name in (
                "init_love", "init_Kw", "init_Km",
                "init_A", "init_Aw", "init_Am", 
                "init_divorces", "init_power",
            ):
                alloc(name, (par.simN,), value=np.nan)

            for name in (
                "init_type_w", "init_type_m",
            ):
                alloc(name, (par.simN,), dtype=np.int32, value=-1000)

            for name in (
                "init_couple",
            ):
                alloc(name, (par.simN,), dtype=np.bool_, value=False)

    def draw_shocks_and_initial_states(self):
        """Draw all shocks for the simulation (using seed for reproducibility)."""
        par = self.par
        sim = self.sim
        
        np.random.seed(par.seed)
        shape_sim = (par.simN, par.simT)
        
        sim.draw_shock_Kw[...] = np.random.lognormal(size=shape_sim, mean=-0.5 * par.sigma_Kw**2, sigma=par.sigma_Kw)
        sim.draw_shock_Km[...] = np.random.lognormal(size=shape_sim, mean=-0.5 * par.sigma_Km**2, sigma=par.sigma_Km)
        sim.draw_love[...] = np.random.normal(size=shape_sim, loc=0.0, scale=par.sigma_love)
        sim.draw_meet[...] = np.random.uniform(size=shape_sim)

        sim.draw_uniform_partner_Kw[...] = np.random.uniform(size=shape_sim)
        sim.draw_uniform_partner_Km[...] = np.random.uniform(size=shape_sim)
        sim.draw_uniform_partner_Aw[...] = np.random.uniform(size=shape_sim)
        sim.draw_uniform_partner_Am[...] = np.random.uniform(size=shape_sim)
        sim.draw_uniform_partner_type_w[...] = np.random.uniform(size=shape_sim)
        sim.draw_uniform_partner_type_m[...] = np.random.uniform(size=shape_sim)
        
        sim.draw_repartner_love[...] = par.sigma_love * np.random.normal(0.0, 1.0, size=shape_sim)
        
        sim.init_A[...] = 0.0
        sim.init_Kw[...] = 0.0
        sim.init_Km[...] = 0.0
        sim.init_Aw[...] = sim.init_A * par.div_A_share
        sim.init_Am[...] = sim.init_A * (1.0 - par.div_A_share)
        sim.init_couple[...] = np.random.choice([True, False], par.simN, p=[par.init_couple_share, 1 - par.init_couple_share])
        sim.init_power[...] = 0.5
        sim.init_love[...] = 0.0
        # sim.init_love[...] = np.random.normal(par.mean_love, par.sigma_love, size=par.simN)
        sim.init_divorces[...] = 0.0
        sim.init_type_w[...] = np.random.choice(par.num_types, par.simN, p=par.type_w_share)
        sim.init_type_m[...] = np.random.choice(par.num_types, par.simN, p=par.type_m_share)
        
        # # allow for correlation in types of couples
        # probs = par.prob_partner_type_w[sim.init_type_w[sim.init_couple]]
        # draws = np.random.rand(probs.shape[0])
        # sim.init_type_m[sim.init_couple] = (draws[:, None] > np.cumsum(probs, axis=1)).sum(axis=1)


    def solve(self):

        sol = self.sol
        par = self.par

        # always ensure sizes/grids are up-to-date (needed for shape checks)
        self.setup_gender_parameters()
        self.setup_grids()
        self.setup_sol(allocate=False)

        self.cpp.solve(sol, par)


    def simulate(self, redraw=False):
        sol = self.sol
        sim = self.sim
        par = self.par

        # Reset simulated outcomes (except for initial conditions and shocks)
        self.setup_sim(allocate=False)
        if redraw:
            self.draw_shocks_and_initial_states()
        self.cpp.simulate(sim,sol,par)

        # auxilliary measures (consumption inequality)
        sim.mean_lifetime_util[0] = (np.mean(np.sum(sim.util_w,axis=1)) + np.mean(np.sum(sim.util_m,axis=1))) / 2.0
        
        adults = np.where(sim.couple == 1, 2.0, 1.0)
        kids = np.where(sim.couple == 1, 0.0, 0.0) # for now, not modeled
        equivalence_scale = (adults + kids*0.7)**0.7 # equivalence scale used in Meyer and Sullivan (2023)
        equivalence_consumption_w = np.where(sim.couple, sim.C_tot, sim.Cw_tot) / equivalence_scale
        equivalence_consumption_m = np.where(sim.couple, sim.C_tot, sim.Cm_tot) / equivalence_scale
        equivalence_consumption = np.concatenate((equivalence_consumption_w, equivalence_consumption_m), axis=0)
        consumption_90_10_ratio = np.nanpercentile(equivalence_consumption, q=90, axis=0) / np.nanpercentile(equivalence_consumption, q=10, axis=0)
        sim.C_ineq_90_10[:] = consumption_90_10_ratio
                    
    # Estimation
    def obj_func(self,theta,estpar,datamoms,weights=None,do_print=False):
        
        # update parameters, impose bounds and return penalty
        penalty = self.update_par(theta,estpar)
        
        # a. solve model
        self.solve()

        # b. simulate
        self.simulate(redraw=True)

        # c. calculate moments
        moms = self.calc_moments()
        
        # d. go through all potential moments and calculate squared difference
        sqdiff = 0.0
        for mom_name in datamoms.keys():
            diff = moms[mom_name] - datamoms[mom_name]
            
            if weights is not None:
                if mom_name in weights:
                    diff *= weights[mom_name]
            
            sqdiff += diff*diff

        objective = sqdiff + penalty
        
        if do_print:
            print('Parameters:')
            for i in range(theta.size):
                name = list(estpar.keys())[i]
                print(f'  {name:<15}: {getattr(self.par,name):.4f} (init: {estpar[name]["guess"]:.4f})') 
            print('Moments:')
            for mom_name in datamoms.keys():
                print(f'  {str(mom_name):<25}: sim: {moms[mom_name]:.4f}, data: {datamoms[mom_name]:.4f}')
            print(f'Objective function value: {objective:.4f} (penalty: {penalty:.4f})')
            print('-------------------------------------')

        return objective


    def calc_moments(self):
        # calculate all potential moments and store in ordered dict
        
        # a) setup
        par = self.par
        sim = self.sim
        moms = OrderedDict()
        money_metric = 1.0 # 10 thousends, so that 1.0 = 10,000 (DKK)
        hours_metric = par.available_hours * 1000 / 52  # full time hours per week
        # b) samples
        ## age groups
        t_array = np.tile(np.arange(par.simT, dtype=int), (par.simN, 1))
        age_25 = 0
        age_25_to_34_mask = (t_array >= age_25) & (t_array <= age_25 + 9)
        age_35_to_41_mask = (t_array >= age_25 + 10) & (t_array <= age_25 + 16) # the 1975 cohort in Eckstein, Keane and Lifshitz (2019) is only observed until age 41
        age_35_to_44_mask = (t_array >= age_25 + 10) & (t_array <= age_25 + 19)
        
        ## full time
        full_time = par.grid_l[-1]
        full_time_w_mask = (sim.lw >= full_time)
        full_time_m_mask = (sim.lm >= full_time)
        
        # unemployment
        unemployed = par.grid_l[0]
        unemployed_w_mask = (sim.lw <= unemployed)
        unemployed_m_mask = (sim.lm <= unemployed)
        
        ## couple
        couple_mask = (sim.couple == 1)
        ever_couple_mask = np.repeat(np.any(sim.couple == 1, axis=1, keepdims=True), par.simT, axis=1)

        # c) moments
        # wages (should be stored in simulation. Now just use labor supply, e.g. lw, for illustration)
        moms['wage_level_w_25_34'] = np.nanmean(sim.wage_inc_w[age_25_to_34_mask & couple_mask & full_time_w_mask]) * money_metric 
        moms['wage_level_m_25_34'] = np.nanmean(sim.wage_inc_m[age_25_to_34_mask & couple_mask & full_time_m_mask]) * money_metric
        moms['wage_level_w_35_41'] = np.nanmean(sim.wage_inc_w[age_35_to_41_mask & couple_mask & full_time_w_mask]) * money_metric
        moms['wage_level_m_35_41'] = np.nanmean(sim.wage_inc_m[age_35_to_41_mask & couple_mask & full_time_m_mask]) * money_metric

        # employment rates
        moms['employment_rate_w_35_41'] = np.nanmean(sim.lw[age_35_to_41_mask & couple_mask] > unemployed) * 100.0
        moms['employment_rate_m_35_41'] = np.nanmean(sim.lm[age_35_to_41_mask & couple_mask] > unemployed) * 100.0
        moms['work_hours_w'] = np.nanmean(sim.lw[age_35_to_44_mask]) * hours_metric
        moms['work_hours_m'] = np.nanmean(sim.lm[age_35_to_44_mask]) * hours_metric
        
        # home production
        moms['home_prod_w'] = np.nanmean(sim.hw[age_35_to_44_mask]) * hours_metric
        moms['home_prod_m'] = np.nanmean(sim.hm[age_35_to_44_mask]) * hours_metric
        
        # consumption
        equivalence_scale_BPS = 2**0.5 # equivalence scaled used in the code of Blundell, Pistaferri, Saporta-Eksten (2018)
        working_couple_mask = couple_mask & (~unemployed_w_mask) & (~unemployed_m_mask)
        moms['consumption'] = np.nanmean(sim.C_tot[working_couple_mask]) / equivalence_scale_BPS * money_metric
        # moms['consumption_sd'] = np.nanstd(np.log(sim.C_tot * money_metric)) * 100.0
        
        # marriage
        moms['marriage_rate_25_34'] = np.nanmean(sim.couple[age_25_to_34_mask]) * 100.0
        moms['marriage_rate_35_41'] = np.nanmean(sim.couple[age_35_to_41_mask]) * 100.0
        moms['divorce_rate_25_34'] = np.nanmean(sim.divorces[age_25_to_34_mask & ever_couple_mask]>0) * 100.0
        moms['divorce_rate_35_44'] = np.nanmean(sim.divorces[age_35_to_44_mask & ever_couple_mask]>0) * 100.0
        
        # inequality
        adults = np.where(sim.couple == 1, 2.0, 1.0)
        kids = np.where(sim.couple == 1, 0.0, 0.0) # for now, not modeled
        equivalence_scale = (adults + kids*0.7)**0.7 # equivalence scale used in Meyer and Sullivan (2023)
        
        # wage inequality: equivalized after-tax household wage income (excluding interest income),
        # for individuals in households with positive wage income
        A_lag = np.concatenate((sim.init_A[:, None], sim.A[:, :-1]), axis=1)
        Aw_lag = np.concatenate((sim.init_Aw[:, None], sim.Aw[:, :-1]), axis=1)
        Am_lag = np.concatenate((sim.init_Am[:, None], sim.Am[:, :-1]), axis=1)
        interest_w = (par.R - 1.0) * np.where(sim.couple, A_lag, Aw_lag)
        interest_m = (par.R - 1.0) * np.where(sim.couple, A_lag, Am_lag)

        gross_wage_w = np.where(sim.couple, sim.wage_inc_w + sim.wage_inc_m, sim.wage_inc_w)
        gross_wage_m = np.where(sim.couple, sim.wage_inc_w + sim.wage_inc_m, sim.wage_inc_m)
        equivalence_wage_w = (sim.after_tax_inc_w - interest_w) / equivalence_scale
        equivalence_wage_m = (sim.after_tax_inc_m - interest_m) / equivalence_scale
        equivalence_wage = np.concatenate((equivalence_wage_w[gross_wage_w > 0.0], equivalence_wage_m[gross_wage_m > 0.0]))
        moms['wage_90_10_ratio'] = np.nanpercentile(equivalence_wage, 90) / np.nanpercentile(equivalence_wage, 10)
        moms['wage_50_10_ratio'] = np.nanpercentile(equivalence_wage, 50) / np.nanpercentile(equivalence_wage, 10)
        moms['wage_90_50_ratio'] = np.nanpercentile(equivalence_wage, 90) / np.nanpercentile(equivalence_wage, 50)
        
        equivalence_consumption_w = np.where(sim.couple, sim.C_tot, sim.Cw_tot) / equivalence_scale
        equivalence_consumption_m = np.where(sim.couple, sim.C_tot, sim.Cm_tot) / equivalence_scale
        equivalence_consumption = np.concatenate(((equivalence_consumption_w).ravel(), (equivalence_consumption_m).ravel()))
        moms['consumption_90_10_ratio'] = np.nanpercentile(equivalence_consumption, 90) / np.nanpercentile(equivalence_consumption, 10)
        moms["consumption_50_10_ratio"] = np.nanpercentile(equivalence_consumption, 50) / np.nanpercentile(equivalence_consumption, 10)
        moms["consumption_90_50_ratio"] = np.nanpercentile(equivalence_consumption, 90) / np.nanpercentile(equivalence_consumption, 50)
        
        moms['female_consumption_share'] = np.nanmean(np.where(sim.couple, sim.Cw_priv, np.nan) / np.where(sim.couple, sim.Cw_priv + sim.Cm_priv, np.nan))
        
        # t_level = 0
        # for dt in (5,10,15):
        #     Iw = (~np.isnan(sim.wage_w[:,t_level+dt])) & (~np.isnan(sim.wage_w[:,t_level+dt-1]))
        #     Im = (~np.isnan(sim.wage_m[:,t_level+dt])) & (~np.isnan(sim.wage_m[:,t_level+dt-1]))
        #     moms[('wage_growth_w',dt)] = np.mean(np.log(sim.wage_w[Iw,t_level+dt])-np.log(sim.wage_w[Iw,t_level+dt-1]))
        #     moms[('wage_growth_m',dt)] = np.mean(np.log(sim.wage_m[Im,t_level+dt])-np.log(sim.wage_m[Im,t_level+dt-1]))

        # # Time allocation
        # moms['time_work_w'] = np.nanmean(sim.lw.ravel()) * hours_metric
        # moms['time_work_m'] = np.nanmean(sim.lm.ravel()) * hours_metric

        # moms['time_leisure_w'] = np.nanmean(sim.leisure_w.ravel()) * hours_metric 
        # moms['time_leisure_m'] = np.nanmean(sim.leisure_m.ravel()) * hours_metric
        
        return moms
    

    def update_par(self,theta,estpar):
        """ update model parameters and impose bounds with penalty """

        if theta is None: return 0
        
        names = list(estpar.keys())
        
        # a. clip and penalty
        penalty = 0
        for i in range(theta.size):
            
            # i. clip
            lower = estpar[names[i]]['lower']
            upper = estpar[names[i]]['upper']
            if (lower != None) or (upper != None):
                theta_clipped = np.clip(theta[i],lower,upper)
            else:
                theta_clipped = theta[i]

            # ii. penalty
            penalty += 10_000.0*(theta[i]-theta_clipped)**2

            ## iii. set clipped value
            setattr(self.par,names[i],theta_clipped)

        return penalty

    def save_par(self,filename):
        import pickle
        par_dict = self.par.__dict__
        folder = 'par_files'
        if not os.path.exists(folder):
            os.makedirs(folder)
        # save as pickle
        with open(f'{folder}/{filename}.pkl', 'wb') as f:
            pickle.dump(par_dict, f)
            
            
    def measure_accuracy(self,true_model):
        par = self.par
        sol = self.sol

        for name in ('grid_power_acc', 'grid_love_acc', 'grid_Kw_acc', 'grid_Km_acc', 'grid_A_acc'):
            assert np.array_equal(getattr(par, name), getattr(true_model.par, name)), f'{name} differs between models'
        num = par.num_acc

        assert par.T == true_model.par.T, 'T differs between models'

        # shapes for allocation
        shape = (par.T, par.num_types, par.num_types, num, num, num, num, num)
        shape_d = (par.T, par.num_types, par.num_types, par.num_l, par.num_l, num, num, num, num, num)

        # local model
        lw = np.empty(shape, dtype=np.float64)
        lm = np.empty(shape, dtype=np.float64)
        power = np.empty(shape, dtype=np.float64)
        power_diff = np.empty(shape, dtype=np.float64)
        C = np.empty(shape_d, dtype=np.float64)
        self.cpp.accuracy_measures(lw, lm, power, power_diff, C, par, sol)

        # true model
        lw_true = np.empty(shape, dtype=np.float64)
        lm_true = np.empty(shape, dtype=np.float64)
        power_true = np.empty(shape, dtype=np.float64)
        power_diff_true = np.empty(shape, dtype=np.float64)
        C_true = np.empty(shape_d, dtype=np.float64)
        true_model.cpp.accuracy_measures(lw_true, lm_true, power_true, power_diff_true, C_true, true_model.par, true_model.sol)

        # deviations
        l_ERROR = (np.sum(lw != lw_true) + np.sum(lm != lm_true)) / (2.0 * lw.size) # average of lw and lm deviations
 
        divorced = (power_diff<-1.0)
        divorced_true = (power_diff_true<-1.0)
        divorce_ERROR = np.mean((divorced) != (divorced_true))
        
        married = (~divorced) & (~divorced_true)
        is_power_updated = (power_diff != 0.0)
        is_power_updated_true = (power_diff_true != 0.0)
        power_ERROR = np.mean((is_power_updated != is_power_updated_true)[married])

        C_MAD = np.mean(np.abs(C / C_true - 1.0) * 100.0)

        return l_ERROR, divorce_ERROR, power_ERROR, C_MAD

      
    def wealth_compensation(self,true_model):
        # search for level of initial wealth that makes mean lifetime utility similar with true model
        sim = self.sim

        mean_lifetime_util_true = true_model.sim.mean_lifetime_util[0]
        expected_income = (true_model.sim.after_tax_inc_w.mean() + true_model.sim.after_tax_inc_m.mean()) / 2.0

        def signed_diff(percent_expected_income_compensation):
            init_A_orig = sim.init_A.copy()
            init_Aw_orig = sim.init_Aw.copy()
            init_Am_orig = sim.init_Am.copy()

            # measure is in percent relative to expected income
            sim.init_A += percent_expected_income_compensation * (2*expected_income) * 0.01 # *0.01 to get percent (not in decimal)
            sim.init_Aw += percent_expected_income_compensation * expected_income * 0.01
            sim.init_Am += percent_expected_income_compensation * expected_income * 0.01
            self.simulate()

            # reset initial wealth for next evaluation
            sim.init_A = init_A_orig
            sim.init_Aw = init_Aw_orig
            sim.init_Am = init_Am_orig

            return sim.mean_lifetime_util[0] - mean_lifetime_util_true

        percent_expected_income_compensation = brentq(signed_diff, -500.0, 500.0)

        # reset
        self.simulate()

        return percent_expected_income_compensation